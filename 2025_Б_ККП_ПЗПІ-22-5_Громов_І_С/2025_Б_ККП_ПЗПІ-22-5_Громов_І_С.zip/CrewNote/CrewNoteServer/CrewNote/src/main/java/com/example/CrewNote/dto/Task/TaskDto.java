package com.example.CrewNote.dto.Task;

import lombok.Data;
import java.util.Date;
import java.util.List;

@Data
public class TaskDto {
    private String id;
    private String projectId;
    private String title;
    private String description;
    private String assignee;
    private String assigneeName; // displayName юзера
    private Date createdAt;
    private Date updatedAt;
    private Date deadline;
    private List<String> tags;
    private String status;
}