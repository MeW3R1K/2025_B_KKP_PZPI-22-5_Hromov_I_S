package com.example.CrewNote.security;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseToken;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import java.io.IOException;
import java.util.Collections;

public class FirebaseAuthenticationFilter extends BasicAuthenticationFilter {

    public FirebaseAuthenticationFilter() {
        super(authentication -> authentication); // we’ll set auth manually
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain chain)
            throws IOException, ServletException {
        String header = request.getHeader("Authorization");
        System.out.println("Authorization header: " + header);
        if (header == null || !header.startsWith("Bearer ")) {
            System.out.println("No Bearer header, skip");
            chain.doFilter(request, response);
            return;
        }
        String idToken = header.substring(7);
        try {
            FirebaseToken decoded = FirebaseAuth.getInstance().verifyIdToken(idToken);
            System.out.println("Firebase token decoded UID: " + decoded.getUid());
            var auth = new UsernamePasswordAuthenticationToken(
                    decoded.getUid(),
                    null,
                    Collections.emptyList()
            );
            SecurityContextHolder.getContext().setAuthentication(auth);
        } catch (Exception e) {
            System.out.println("Firebase token error: " + e.getMessage());
            throw new AuthenticationCredentialsNotFoundException("Invalid Firebase ID token", e);
        }
        chain.doFilter(request, response);
    }

}
