package com.example.CrewNote.service;

import com.example.CrewNote.dto.User.UpdateUserRequest;
import com.example.CrewNote.dto.User.UserDto;
import com.example.CrewNote.model.User;
import com.example.CrewNote.repository.UserRepository;
import com.google.firebase.auth.FirebaseToken;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.context.SecurityContextHolder;  // ← цей імпорт!
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import java.util.Collections;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;

    public Mono<User> createIfNotExists(User user) {
        user.setPhotoUrl("/avatars/avatar1.jpg");
        return userRepository.findById(user.getId())
                .switchIfEmpty(userRepository.save(user));
    }

    public Mono<User> upsertFromToken(FirebaseToken decoded) {
        String uid = decoded.getUid();
        return userRepository.findById(uid)
                .defaultIfEmpty(User.builder()
                        .id(uid)
                        .email(decoded.getEmail())
                        .displayName(decoded.getName())
                        .photoUrl(decoded.getPicture())
                        .roles(Collections.emptyList())
                        .build()
                )
                .flatMap(existing -> {
                    // оновимо поля
                    existing.setEmail(decoded.getEmail());
                    existing.setDisplayName(decoded.getName());
                    existing.setPhotoUrl(decoded.getPicture());
                    return userRepository.save(existing);
                });
    }

    /**
     * Повернути поточного користувача
     */
    public Mono<User> getCurrent() {
        String uid = (String) SecurityContextHolder
                .getContext()
                .getAuthentication()
                .getPrincipal();

        log.debug("getCurrent(): fetching user with uid={}", uid);

        return userRepository.findById(uid)
                .doOnNext(user -> {
                    log.debug("Fetched user: {}", user);
                    log.debug("Fetched roles: {}", user.getRoles());
                })
                .switchIfEmpty(Mono.defer(() -> {
                    log.debug("No user document found for uid={}", uid);
                    return Mono.empty();
                }));
    }

    public Mono<List<UserDto>> findByIds(List<String> ids) {
        return Flux.fromIterable(ids)
                .flatMap(userRepository::findById)
                .map(user -> new UserDto(
                        user.getId(),
                        user.getDisplayName(),
                        user.getPhotoUrl()
                        // додай ще потрібні поля
                ))
                .collectList();
    }


    public Flux<String> findProjectIdsForCurrentUser() {
        String uid = (String) SecurityContextHolder
                .getContext()
                .getAuthentication()
                .getPrincipal();
        return userRepository.findById(uid)
                .flatMapMany(user ->
                        Flux.fromIterable(user.getRoles().stream()
                                .map(role -> role.getProjectId())
                                .collect(Collectors.toList()))
                );
    }

    public Mono<User> updateCurrentUser(UpdateUserRequest req) {
        return getCurrent()
                .flatMap(user -> {
                    if (req.getDisplayName() != null) user.setDisplayName(req.getDisplayName());
                    if (req.getPhotoUrl() != null) user.setPhotoUrl(req.getPhotoUrl());
                    // збережи користувача:
                    return userRepository.save(user);
                });
    }
}