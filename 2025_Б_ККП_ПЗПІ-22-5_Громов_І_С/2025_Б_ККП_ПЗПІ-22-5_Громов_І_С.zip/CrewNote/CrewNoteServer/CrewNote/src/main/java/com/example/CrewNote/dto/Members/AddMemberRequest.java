package com.example.CrewNote.dto.Members;

import lombok.Data;

@Data
public class AddMemberRequest {
    private String userId;
    private String role; // admin | member | viewer
}
