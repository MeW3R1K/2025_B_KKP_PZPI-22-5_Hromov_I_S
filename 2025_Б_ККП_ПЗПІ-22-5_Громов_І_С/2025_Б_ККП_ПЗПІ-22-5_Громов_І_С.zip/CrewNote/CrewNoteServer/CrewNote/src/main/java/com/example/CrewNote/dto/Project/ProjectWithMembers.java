package com.example.CrewNote.dto.Project;

import com.example.CrewNote.model.Member;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProjectWithMembers {
    private String id;
    private String name;
    private String description;
    private Date createdAt;
    private Date updatedAt;
    private List<Member> members;
}
