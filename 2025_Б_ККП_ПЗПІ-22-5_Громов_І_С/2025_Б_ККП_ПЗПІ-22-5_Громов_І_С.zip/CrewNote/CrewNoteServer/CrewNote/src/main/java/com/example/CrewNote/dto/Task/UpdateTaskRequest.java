package com.example.CrewNote.dto.Task;

import lombok.Data;
import java.util.Date;
import java.util.List;

@Data
public class UpdateTaskRequest {
    private String title;
    private String description;
    private String assignee;
    private Date deadline;
    private List<String> tags;
    private String status;
}
