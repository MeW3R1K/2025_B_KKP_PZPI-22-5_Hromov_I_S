package com.example.CrewNote.service;

import com.example.CrewNote.model.LogEntry;
import com.example.CrewNote.repository.LogEntryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.Date;

@Service
@RequiredArgsConstructor
public class LogService {

    private final LogEntryRepository logEntryRepository;

    public Mono<LogEntry> logAction(String action, String targetType, String targetId, String userId,
                                    String oldValue, String newValue) {
        LogEntry entry = LogEntry.builder()
                .action(action)
                .targetType(targetType)
                .targetId(targetId)
                .userId(userId)
                .timestamp(new Date())
                .oldValue(oldValue)
                .newValue(newValue)
                .build();
        return logEntryRepository.save(entry);
    }
}
