package com.example.CrewNote.service;

import com.example.CrewNote.dto.Dasboard.*;
import com.example.CrewNote.model.Project;
import com.example.CrewNote.model.Task;
import com.example.CrewNote.model.User;
import com.example.CrewNote.repository.ProjectRepository;
import com.example.CrewNote.repository.TaskRepository;
import com.example.CrewNote.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class DashboardService {

    private final TaskRepository taskRepository;
    private final ProjectRepository projectRepository;
    private final UserRepository userRepository;

    public DashboardService(TaskRepository taskRepo, ProjectRepository projectRepo, UserRepository userRepo) {
        this.taskRepository = taskRepo;
        this.projectRepository = projectRepo;
        this.userRepository = userRepo;
    }

    public DashboardStatsDto getDashboardStats(String projectId) {
        // 1. Завантажити задачі проекту
        List<Task> tasks = taskRepository.findByProjectId(projectId).collectList().block();

        // 2. Завантажити проект і його учасників
        Project project = projectRepository.findById(projectId).block();

        // 3. Знайти всіх users, які мають роль у цьому проекті
        List<User> allUsers = userRepository.findAll().collectList().block();
        List<User> members = allUsers.stream()
                .filter(u -> u.getRoles() != null && u.getRoles().stream()
                        .anyMatch(r -> r.getProjectId().equals(projectId)))
                .collect(Collectors.toList());

        // 4. Підготувати дані для DashboardStatsDto
        DashboardStatsDto dto = new DashboardStatsDto();

        // === Статус-контроль ===
        Map<String, Integer> statusMap = new HashMap<>();
        for (Task t : tasks) {
            statusMap.put(t.getStatus(), statusMap.getOrDefault(t.getStatus(), 0) + 1);
        }
        List<StatusCount> statusCounts = statusMap.entrySet().stream()
                .map(e -> new StatusCount(e.getKey(), e.getValue()))
                .collect(Collectors.toList());
        dto.setStatusCounts(statusCounts);

        // === Відсоток виконання ===
        int total = tasks.size();
        int done = (int) tasks.stream().filter(t -> "done".equals(t.getStatus())).count();
        dto.setPercentDone(total > 0 ? (done * 100) / total : 0);

        // === Tasks по учасниках ===
        List<MemberStats> memberStats = members.stream().map(m -> {
            int count = (int) tasks.stream().filter(t -> t.getAssignee() != null && t.getAssignee().equals(m.getId())).count();
            return new MemberStats(m.getId(), m.getDisplayName(), count);
        }).collect(Collectors.toList());
        dto.setMemberStats(memberStats);

        // === Просрочені задачі ===
        Date now = new Date();
        List<TaskShortDto> overdue = tasks.stream()
                .filter(t -> t.getDeadline() != null && t.getDeadline().before(now) && !"done".equals(t.getStatus()))
                .map(t -> new TaskShortDto(t.getId(), t.getTitle(), t.getDeadline().toString(), t.getStatus()))
                .collect(Collectors.toList());
        dto.setOverdueTasks(overdue);

        // === Дедлайни на тиждень вперед ===
        Calendar cal = Calendar.getInstance();
        cal.setTime(now);
        cal.add(Calendar.DAY_OF_YEAR, 7);
        Date weekEnd = cal.getTime();
        List<TaskShortDto> upcoming = tasks.stream()
                .filter(t -> t.getDeadline() != null && !t.getDeadline().before(now) && !t.getDeadline().after(weekEnd))
                .map(t -> new TaskShortDto(t.getId(), t.getTitle(), t.getDeadline().toString(), t.getStatus()))
                .sorted(Comparator.comparing(TaskShortDto::getDeadline))
                .collect(Collectors.toList());
        dto.setUpcomingTasks(upcoming);

        // === Список учасників ===
        List<MemberShortDto> memberShortDtos = members.stream().map(
                u -> new MemberShortDto(u.getId(), u.getDisplayName(), u.getPhotoUrl())
        ).collect(Collectors.toList());
        dto.setMembers(memberShortDtos);

        return dto;
    }
}

