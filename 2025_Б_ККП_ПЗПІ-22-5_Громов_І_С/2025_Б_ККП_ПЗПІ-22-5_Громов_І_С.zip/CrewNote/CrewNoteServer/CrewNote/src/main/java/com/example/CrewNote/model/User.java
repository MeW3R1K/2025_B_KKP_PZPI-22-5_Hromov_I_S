package com.example.CrewNote.model;

import com.google.cloud.spring.data.firestore.Document;
import com.google.cloud.firestore.annotation.DocumentId;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collectionName = "users")
public class User {
    @DocumentId
    private String id;
    private String email;
    private String displayName;
    private String photoUrl;

    /** Ролі користувача у проєктах */
    private List<ProjectRole> roles;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ProjectRole {
        private String projectId;
        private String role;           // Admin | Member | Viewer
    }
}

