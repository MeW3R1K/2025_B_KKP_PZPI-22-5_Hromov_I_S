package com.example.CrewNote.dto.Task;

import lombok.Data;
import java.util.Date;
import java.util.List;

@Data
public class CreateTaskRequest {
    private String title;
    private String description;
    private String assignee;     // ID користувача
    private Date deadline;
    private String projectId;
    private List<String> tags;
}

