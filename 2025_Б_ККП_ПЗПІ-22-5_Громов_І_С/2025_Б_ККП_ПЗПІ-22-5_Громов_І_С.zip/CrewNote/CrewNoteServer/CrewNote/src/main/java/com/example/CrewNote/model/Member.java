package com.example.CrewNote.model;

import com.google.cloud.firestore.annotation.DocumentId;
import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Member {
    @DocumentId
    private String id;
    private String role; // "admin", "member"
}
