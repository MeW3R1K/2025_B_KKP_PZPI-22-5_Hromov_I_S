package com.example.CrewNote.repository;

import com.example.CrewNote.model.Project;
import com.google.cloud.spring.data.firestore.FirestoreReactiveRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

@Repository
public interface ProjectRepository extends FirestoreReactiveRepository<Project> {
}
