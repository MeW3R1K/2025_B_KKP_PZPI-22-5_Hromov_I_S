package com.example.CrewNote.controller;

import com.example.CrewNote.dto.User.UpdateUserRequest;
import com.example.CrewNote.dto.User.UserDto;
import com.example.CrewNote.model.User;
import com.example.CrewNote.repository.UserRepository;
import com.example.CrewNote.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.List;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;
    private final UserRepository userRepository;

    /** Повернути профіль поточного користувача */
    @GetMapping("/me")
    public Mono<User> me() {
        System.out.println("Викликано /api/users/me!");
        Mono<User> res = userService.getCurrent();
        return res;
    }

    @PatchMapping("/me")
    public Mono<User> updateProfile(@RequestBody UpdateUserRequest request) {
        return userService.updateCurrentUser(request);
    }

    /** Повернути будь–якого користувача за ID (Admin only) */
    @GetMapping("/{id}")
    public Mono<User> getById(@PathVariable String id) {
        return userService.getCurrent()
                .flatMap(current -> {
                    // тут можна перевірити роль Admin глобально або в конкретному проекті
                    return userRepository.findById(id);
                });
    }

    @PostMapping("/batch")
    public Mono<List<UserDto>> getUsersBatch(@RequestBody List<String> ids) {
        return userService.findByIds(ids); // Повертає Mono<List<UserDto>>
    }

    @PostMapping
    public Mono<User> createUser(@RequestBody User user) {
        return userService.createIfNotExists(user);
    }




}

