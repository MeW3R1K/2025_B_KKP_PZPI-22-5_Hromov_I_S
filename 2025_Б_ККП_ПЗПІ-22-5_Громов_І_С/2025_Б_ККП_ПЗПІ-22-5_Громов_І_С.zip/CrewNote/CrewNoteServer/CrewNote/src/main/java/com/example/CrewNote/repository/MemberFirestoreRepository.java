package com.example.CrewNote.repository;

import com.google.cloud.firestore.Firestore;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class MemberFirestoreRepository {
    @Autowired
    private Firestore firestore;

    public CollectionReference getMembersCollection(String projectId) {
        return firestore.collection("projects").document(projectId).collection("members");
    }
}

