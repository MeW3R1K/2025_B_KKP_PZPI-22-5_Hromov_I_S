package com.example.CrewNote;

import com.google.cloud.spring.data.firestore.repository.config.EnableReactiveFirestoreRepositories;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@EnableReactiveFirestoreRepositories(basePackages = "com.example.CrewNote.repository")
public class CrewNoteApplication {

	public static void main(String[] args) throws Exception  {
		SpringApplication.run(CrewNoteApplication.class, args);
	}

}
