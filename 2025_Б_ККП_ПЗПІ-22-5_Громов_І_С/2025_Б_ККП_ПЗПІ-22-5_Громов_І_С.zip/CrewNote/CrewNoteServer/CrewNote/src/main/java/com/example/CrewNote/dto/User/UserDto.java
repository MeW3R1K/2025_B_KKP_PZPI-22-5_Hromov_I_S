package com.example.CrewNote.dto.User;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
public class UserDto {
    private String id;
    private String displayName;
    private String avatarUrl;
}
