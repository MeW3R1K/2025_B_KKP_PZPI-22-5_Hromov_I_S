package com.example.CrewNote.service;

import com.example.CrewNote.dto.Project.CreateProjectRequest;
import com.example.CrewNote.dto.Project.ProjectWithMembers;
import com.example.CrewNote.dto.Project.UpdateProjectRequest;
import com.example.CrewNote.model.LogEntry;
import com.example.CrewNote.model.Project;
import com.example.CrewNote.model.Member;
import com.example.CrewNote.repository.ProjectRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.cloud.firestore.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.*;

import com.google.api.core.ApiFuture;
import java.util.concurrent.CompletableFuture;


@Service
@RequiredArgsConstructor
public class ProjectService {

    private final ProjectRepository projectRepository;
    private final LogService logService;
    private final Firestore firestore;
    private final ObjectMapper objectMapper = new ObjectMapper();


    public static <T> CompletableFuture<T> toCompletableFuture(ApiFuture<T> apiFuture) {
        CompletableFuture<T> completableFuture = new CompletableFuture<>();
        new Thread(() -> {
            try {
                completableFuture.complete(apiFuture.get());
            } catch (Exception e) {
                completableFuture.completeExceptionally(e);
            }
        }).start();
        return completableFuture;
    }

    // ----------- PROJECT CRUD -----------

    /** Отримати всі проекти, де userId є учасником */
    public Flux<ProjectWithMembers> getAllByUser(String userId) {
        // Витягуємо всі проекти (не дуже ефективно, але якщо проектів небагато — ок)
        return Flux.fromIterable(firestore.collection("projects").listDocuments())
                .flatMap(docRef -> Mono.fromFuture(() -> toCompletableFuture(docRef.get()))
                        .flatMap(snapshot -> {
                            if (!snapshot.exists()) return Mono.empty();
                            Project project = snapshot.toObject(Project.class);
                            project.setId(snapshot.getId());
                            CollectionReference membersCol = docRef.collection("members");
                            return Mono.fromFuture(() -> toCompletableFuture(membersCol.document(userId).get()))
                                    .flatMap(memberSnap -> {
                                        if (!memberSnap.exists()) return Mono.empty();
                                        // Тепер збираємо всіх учасників:
                                        return Mono.fromFuture(() -> toCompletableFuture(membersCol.get()))
                                                .map(memSnap -> {
                                                    List<Member> members = new ArrayList<>();
                                                    for (DocumentSnapshot m : memSnap.getDocuments()) {
                                                        members.add(m.toObject(Member.class));
                                                    }
                                                    return ProjectWithMembers.builder()
                                                            .id(project.getId())
                                                            .name(project.getName())
                                                            .description(project.getDescription())
                                                            .createdAt(project.getCreatedAt())
                                                            .updatedAt(project.getUpdatedAt())
                                                            .members(members)
                                                            .build();
                                                });
                                    });
                        })
                );
    }


    /** Створити новий проект і додати userId як адміна у members-підколекцію */
    public Mono<ProjectWithMembers> createProject(CreateProjectRequest request, String userId) {
        // 1. Створюємо новий проект (без members)
        Project project = Project.builder()
                .name(request.getName())
                .description(request.getDescription())
                .createdAt(new Date())
                .updatedAt(new Date())
                .build();

        // Firestore: отримаємо новий document reference
        DocumentReference projectRef = firestore.collection("projects").document(); // генерує ID
        project.setId(projectRef.getId());

        // 2. Записуємо сам проект (без members)
        ApiFuture<WriteResult> saveProject = projectRef.set(project);

        // 3. Додаємо адміна в підколекцію members
        Member admin = new Member(userId, "admin");
        CollectionReference membersCol = projectRef.collection("members");
        ApiFuture<WriteResult> saveMember = membersCol.document(userId).set(admin);


         CollectionReference logsCol = projectRef.collection("logs");
         LogEntry log = LogEntry.builder()
                 .action("create_project")
                 .targetType("project")
                 .targetId(project.getId())
                 .userId(userId)
                 .timestamp(new Date())
                 .oldValue(null)
                 .newValue(toJsonSafe(project))
                 .build();
         ApiFuture<DocumentReference> saveLog = logsCol.add(log);

        // 5. Обгортаємо в Mono (реактивний стиль)
        return Mono.fromFuture(() -> toCompletableFuture(saveProject))
                .then(Mono.fromFuture(() -> toCompletableFuture(saveMember)))
                .then(Mono.fromFuture(() -> toCompletableFuture(saveLog)))
                .then(getById(project.getId()));
    }

    /** Отримати проект за id */
    public Mono<ProjectWithMembers> getById(String id) {
        DocumentReference docRef = firestore.collection("projects").document(id);
        return Mono.fromFuture(() -> toCompletableFuture(docRef.get()))
                .flatMap(snapshot -> {
                    if (!snapshot.exists()) return Mono.empty();
                    Project project = snapshot.toObject(Project.class);
                    project.setId(snapshot.getId());

                    CollectionReference membersCol = docRef.collection("members");
                    return Mono.fromFuture(() -> toCompletableFuture(membersCol.get()))
                            .map(memSnap -> {
                                List<Member> members = new ArrayList<>();
                                for (DocumentSnapshot m : memSnap.getDocuments()) {
                                    members.add(m.toObject(Member.class));
                                }
                                return ProjectWithMembers.builder()
                                        .id(project.getId())
                                        .name(project.getName())
                                        .description(project.getDescription())
                                        .createdAt(project.getCreatedAt())
                                        .updatedAt(project.getUpdatedAt())
                                        .members(members)
                                        .build();
                            });
                });
    }

    /** Оновити проект (тільки якщо користувач — адмін) */
    public Mono<ProjectWithMembers> updateProject(String id, UpdateProjectRequest request) {
        DocumentReference docRef = firestore.collection("projects").document(id);
        Map<String, Object> updates = new HashMap<>();
        if (request.getName() != null) updates.put("name", request.getName());
        if (request.getDescription() != null) updates.put("description", request.getDescription());
        updates.put("updatedAt", new Date());
        return Mono.fromFuture(() -> toCompletableFuture(docRef.update(updates)))
                .then(getById(id)); // після оновлення повертати актуальний проект
    }


    private String toJsonSafe(Project project) {
        try {
            return objectMapper.writeValueAsString(project);
        } catch (Exception e) {
            return project.toString();
        }
    }

    /** Видалити проект (тільки якщо користувач — адмін) */
    public Mono<Void> deleteProject(String projectId, String userId) {
        return isAdmin(projectId, userId)
                .flatMap(isAdmin -> {
                    if (!isAdmin) return Mono.empty();
                    return projectRepository.findById(projectId)
                            .flatMap(existing ->
                                    projectRepository.deleteById(projectId)
                                            .then(logService.logAction(
                                                    "delete_project",
                                                    "project",
                                                    projectId,
                                                    userId,
                                                    toJsonSafe(existing),
                                                    null
                                            ))
                            );
                }).then();
    }

    // ----------- MEMBERS CRUD -----------

    /** Додати учасника у підколекцію (admin only) */
    public Mono<Void> addMember(String projectId, Member member) {
        CollectionReference membersCol = firestore.collection("projects").document(projectId).collection("members");
        ApiFuture<WriteResult> future = membersCol.document(member.getId()).set(member);
        return Mono.fromFuture(() -> toCompletableFuture(future)).then();
    }


    /** Видалити учасника */
    public Mono<Void> removeMember(String projectId, String memberUserId, String currentUserId) {
        return isAdmin(projectId, currentUserId)
                .flatMap(isAdmin -> {
                    if (!isAdmin) return Mono.empty();
                    CollectionReference membersCol = firestore.collection("projects")
                            .document(projectId).collection("members");
                    ApiFuture<WriteResult> future = membersCol.document(memberUserId).delete();
                    return Mono.fromFuture(() -> toCompletableFuture(future)).then();
                });
    }


    /** Отримати всіх учасників проекту */
    public Flux<Member> getMembers(String projectId) {
        CollectionReference membersCol = firestore.collection("projects").document(projectId).collection("members");
        ApiFuture<QuerySnapshot> future = membersCol.get();
        return Mono.fromFuture(() -> toCompletableFuture(future))
                .flatMapMany(querySnapshot -> Flux.fromIterable(querySnapshot.getDocuments()))
                .map(doc -> doc.toObject(Member.class));
    }

    /** Чи є currentUserId адміном в проекті? */
    public Mono<Boolean> isAdmin(String projectId, String userId) {
        CollectionReference membersCol = firestore.collection("projects").document(projectId).collection("members");
        ApiFuture<DocumentSnapshot> future = membersCol.document(userId).get();
        return Mono.fromFuture(() -> toCompletableFuture(future))
                .map(doc -> {
                    Member member = doc.toObject(Member.class);
                    return member != null && "admin".equals(member.getRole());
                });
    }

    // ----------- INTERNAL -----------

    private Mono<Void> addMemberInternal(String projectId, Member member) {
        CollectionReference membersCol = firestore.collection("projects")
                .document(projectId).collection("members");
        ApiFuture<WriteResult> future = membersCol.document(member.getId()).set(member);
        return Mono.fromFuture(() -> toCompletableFuture(future)).then();
    }

    public Mono<Void> addLog(String projectId, LogEntry entry) {
        CollectionReference logsCol = firestore.collection("projects")
                .document(projectId).collection("logs");
        ApiFuture<WriteResult> future = logsCol.document().set(entry);
        return Mono.fromFuture(() -> {
            CompletableFuture<WriteResult> completable = new CompletableFuture<>();
            new Thread(() -> {
                try { completable.complete(future.get()); }
                catch (Exception e) { completable.completeExceptionally(e); }
            }).start();
            return completable;
        }).then();
    }

    public Flux<LogEntry> getLogs(String projectId) {
        CollectionReference logsCol = firestore.collection("projects")
                .document(projectId).collection("logs");
        ApiFuture<QuerySnapshot> future = logsCol.orderBy("timestamp").get();
        return Mono.fromFuture(() -> toCompletableFuture(future))
                .flatMapMany(qs -> Flux.fromIterable(qs.getDocuments()))
                .map(doc -> doc.toObject(LogEntry.class));
    }

    public Mono<LogEntry> getLog(String projectId, String logId) {
        CollectionReference logsCol = firestore.collection("projects")
                .document(projectId).collection("logs");
        ApiFuture<DocumentSnapshot> future = logsCol.document(logId).get();
        return Mono.fromFuture(() -> toCompletableFuture(future))
                .map(doc -> doc.toObject(LogEntry.class));
    }

}
