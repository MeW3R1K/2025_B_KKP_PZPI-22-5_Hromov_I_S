package com.example.CrewNote.model;

import com.google.cloud.firestore.annotation.DocumentId;
import lombok.*;
import java.util.Date;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LogEntry {
    @DocumentId
    private String id;
    private String action;
    private String targetId;
    private String targetType;
    private String oldValue;
    private String newValue;
    private Date timestamp;
    private String userId;

    public static LogEntry taskLog(String action, String userId, Task oldTask, Task newTask) {
        LogEntry log = new LogEntry();
        log.setAction(action);
        log.setUserId(userId);
        log.setTargetType("task");
        log.setTargetId(newTask != null ? newTask.getId() : oldTask != null ? oldTask.getId() : null);
        log.setTimestamp(new Date());

        ObjectMapper mapper = new ObjectMapper();
        try {
            log.setOldValue(oldTask != null ? mapper.writeValueAsString(oldTask) : null);
            log.setNewValue(newTask != null ? mapper.writeValueAsString(newTask) : null);
        } catch (JsonProcessingException e) {
            log.setOldValue("error");
            log.setNewValue("error");
        }

        return log;
    }
}
