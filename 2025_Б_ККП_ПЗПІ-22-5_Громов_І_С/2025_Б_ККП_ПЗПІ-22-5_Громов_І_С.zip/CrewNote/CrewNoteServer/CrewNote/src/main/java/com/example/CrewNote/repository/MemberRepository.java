package com.example.CrewNote.repository;

import com.example.CrewNote.model.Member;
import com.google.cloud.spring.data.firestore.FirestoreReactiveRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MemberRepository extends FirestoreReactiveRepository<Member> {}
