package com.example.CrewNote.dto;

import lombok.Data;

@Data
public class AuthResponse {
    private String uid;
    private String email;
    private String displayName;
    private String photoUrl;
}