package com.example.CrewNote.service;

import com.example.CrewNote.dto.Task.CreateTaskRequest;
import com.example.CrewNote.dto.Task.UpdateTaskRequest;
import com.example.CrewNote.model.Comment;
import com.example.CrewNote.model.Task;
import com.example.CrewNote.repository.TaskRepository;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.QuerySnapshot;
import com.google.cloud.firestore.WriteResult;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;
import reactor.util.function.Tuples;

import java.util.Date;
import java.util.concurrent.CompletableFuture;

@Service
@RequiredArgsConstructor
public class TaskService {

    private final TaskRepository taskRepository;
    private final Firestore firestore;

    public Mono<Task> createTask(CreateTaskRequest request, String currentUserId) {
        Task task = Task.builder()
                .title(request.getTitle())
                .description(request.getDescription())
                .status("new")
                .tags(request.getTags())
                .projectId(request.getProjectId())
                .assignee(request.getAssignee())
                .deadline(request.getDeadline())
                .createdAt(new Date())
                .updatedAt(new Date())
                .build();

        return taskRepository.save(task)
                .flatMap(savedTask -> {
                    // comments створюється автоматично у Firestore при додаванні першого коментаря,
                    // але якщо хочеш створити порожню — зроби це тут.
                    // Приклад: додати перший коментар або просто нічого не робити, бо підколекція створюється автоматично.
                    return Mono.just(savedTask);
                });
    }

    // Update Task
    public Mono<Tuple2<Task, Task>> updateTask(String id, UpdateTaskRequest req, String currentUserId) {
        return taskRepository.findById(id)
                .flatMap(oldTask -> {
                    // Створюємо копію старого завдання для oldValue
                    Task oldCopy = Task.builder()
                            .id(oldTask.getId())
                            .title(oldTask.getTitle())
                            .description(oldTask.getDescription())
                            .status(oldTask.getStatus())
                            .projectId(oldTask.getProjectId())
                            .assignee(oldTask.getAssignee())
                            .deadline(oldTask.getDeadline())
                            .createdAt(oldTask.getCreatedAt())
                            .updatedAt(oldTask.getUpdatedAt())
                            .build();

                    // Оновлюємо поля
                    if (req.getTitle() != null) oldTask.setTitle(req.getTitle());
                    if (req.getDescription() != null) oldTask.setDescription(req.getDescription());
                    if (req.getStatus() != null) oldTask.setStatus(req.getStatus());
                    if (req.getAssignee() != null) oldTask.setAssignee(req.getAssignee());
                    if (req.getDeadline() != null) oldTask.setDeadline(req.getDeadline());
                    oldTask.setUpdatedAt(new Date());

                    return taskRepository.save(oldTask)
                            .map(updatedTask -> Tuples.of(oldCopy, updatedTask));
                });
    }

    // Delete Task
    public Mono<Task> deleteTask(String id, String userId) {
        return taskRepository.findById(id)
                .flatMap(task ->
                        taskRepository.deleteById(id).thenReturn(task)
                );
    }


    public Flux<Task> getTasksForProject(String projectId, String currentUserId, boolean isAdmin) {
        if (isAdmin) {
            // Повертаємо всі задачі цього проекту
            return taskRepository.findByProjectId(projectId);
        } else {
            // Тільки задачі, де користувач є виконавцем (assignee)
            return taskRepository.findByProjectIdAndAssignee(projectId, currentUserId);
        }
    }

    // Додати коментар
    public Mono<Void> addComment(String taskId, Comment comment) {
        CollectionReference commentsCol = firestore.collection("tasks").document(taskId).collection("comments");
        ApiFuture<WriteResult> future = commentsCol.document().set(comment);
        return Mono.fromFuture(() -> {
            CompletableFuture<WriteResult> completable = new CompletableFuture<>();
            new Thread(() -> {
                try { completable.complete(future.get()); }
                catch (Exception e) { completable.completeExceptionally(e); }
            }).start();
            return completable;
        }).then();
    }

    // Отримати коментарі
    public Flux<Comment> getComments(String taskId) {
        CollectionReference commentsCol = firestore.collection("tasks").document(taskId).collection("comments");
        ApiFuture<QuerySnapshot> future = commentsCol.get();
        return Mono.fromFuture(() -> {
                    CompletableFuture<QuerySnapshot> completable = new CompletableFuture<>();
                    new Thread(() -> {
                        try { completable.complete(future.get()); }
                        catch (Exception e) { completable.completeExceptionally(e); }
                    }).start();
                    return completable;
                }).flatMapMany(snapshot -> Flux.fromIterable(snapshot.getDocuments()))
                .map(doc -> doc.toObject(Comment.class));
    }



}