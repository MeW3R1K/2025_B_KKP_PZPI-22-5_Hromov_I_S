package com.example.CrewNote.controller;

import com.example.CrewNote.dto.Members.AddMemberRequest;
import com.example.CrewNote.dto.Project.CreateProjectRequest;
import com.example.CrewNote.dto.Project.ProjectWithMembers;
import com.example.CrewNote.dto.Project.UpdateProjectRequest;
import com.example.CrewNote.model.LogEntry;
import com.example.CrewNote.model.Member;
import com.example.CrewNote.service.ProjectService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/projects")
@RequiredArgsConstructor
public class ProjectController {

    private final ProjectService projectService;

    private String getCurrentUserId() {
        return (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    }

    // 1. Список проектів користувача (із members)
    @GetMapping
    public Flux<ProjectWithMembers> getAllProjectsForCurrentUser() {
        String userId = getCurrentUserId();
        return projectService.getAllByUser(userId);
    }

    // 2. Створення проекту
    @PostMapping
    public Mono<ProjectWithMembers> createProject(@RequestBody CreateProjectRequest request) {
        String userId = getCurrentUserId();
        return projectService.createProject(request, userId);
    }

    // 3. Перегляд проекту
    @GetMapping("/{id}")
    public Mono<ProjectWithMembers> getProject(@PathVariable String id) {
        return projectService.getById(id);
    }

    // 4. Оновлення проекту
    @PatchMapping("/{id}")
    public Mono<ProjectWithMembers> updateProject(@PathVariable String id, @RequestBody UpdateProjectRequest request) {
        return projectService.updateProject(id, request);
    }

    // 5. Видалення проекту
    @DeleteMapping("/{id}")
    public Mono<Void> deleteProject(@PathVariable String id) {
        String userId = getCurrentUserId();
        return projectService.deleteProject(id, userId);
    }

    // 6. Список учасників (чисто members)
    @GetMapping("/{id}/members")
    public Flux<Member> getProjectMembers(@PathVariable String id) {
        return projectService.getMembers(id);
    }

    // 7. Додавання учасника
    @PostMapping("/{id}/members")
    public Mono<Void> addMember(@PathVariable String id, @RequestBody AddMemberRequest request) {
        // Витягуй роль з request, userId з request.userId
        return projectService.addMember(id, new Member(request.getUserId(), request.getRole()));
    }

    // 8. Видалення учасника
    @DeleteMapping("/{id}/members/{memberId}")
    public Mono<Void> removeMember(@PathVariable String id, @PathVariable String memberId) {
        String userId = getCurrentUserId();
        return projectService.removeMember(id, memberId, userId);
    }

    @GetMapping("/{id}/logs")
    public Flux<LogEntry> getLogs(@PathVariable String id) {
        return projectService.getLogs(id);
    }
}

