package com.example.CrewNote.controller;

import com.example.CrewNote.dto.Task.CreateTaskRequest;
import com.example.CrewNote.dto.Task.UpdateTaskRequest;
import com.example.CrewNote.model.Comment;
import com.example.CrewNote.model.LogEntry;
import com.example.CrewNote.model.Task;
import com.example.CrewNote.repository.TaskRepository;
import com.example.CrewNote.service.ProjectService;
import com.example.CrewNote.service.TaskService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Date;

@RestController
@RequestMapping("/api/tasks")
@RequiredArgsConstructor
public class TaskController {

    private final TaskService taskService;
    private final ProjectService projectService;
    private final TaskRepository taskRepository;

    private String getCurrentUserId() {
        return (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    }

    // 1. Список задач для поточного проекту
    @GetMapping
    public Flux<Task> getTasks(@RequestParam String projectId) {
        String userId = getCurrentUserId();
        return projectService.isAdmin(projectId, userId)
                .flatMapMany(isAdmin -> taskService.getTasksForProject(projectId, userId, isAdmin));
    }

    // 2. Створити задачу
    @PostMapping
    public Mono<Task> createTask(@RequestBody CreateTaskRequest req) {
        String userId = getCurrentUserId();
        return taskService.createTask(req, userId)
                .flatMap(task -> {
                    LogEntry log = LogEntry.taskLog("create_task", userId, null, task);
                    return projectService.addLog(task.getProjectId(), log).thenReturn(task);
                });
    }

    // 3. Отримати задачу за id
    @GetMapping("/{id}")
    public Mono<Task> getTask(@PathVariable String id) {
        return taskRepository.findById(id);
    }

    // 4. Оновити задачу
    @PatchMapping("/{id}")
    public Mono<Task> updateTask(@PathVariable String id, @RequestBody UpdateTaskRequest req) {
        String userId = getCurrentUserId();
        return taskService.updateTask(id, req, userId)
                .flatMap(tuple -> {
                    Task oldTask = tuple.getT1();
                    Task updatedTask = tuple.getT2();
                    LogEntry log = LogEntry.taskLog("update_task", userId, oldTask, updatedTask);
                    return projectService.addLog(updatedTask.getProjectId(), log).thenReturn(updatedTask);
                });
    }

    // 5. Видалити задачу
    @DeleteMapping("/{id}")
    public Mono<Void> deleteTask(@PathVariable String id) {
        String userId = getCurrentUserId();
        // В TaskService потрібно реалізувати повернення Mono<Task> видаленої задачі
        return taskService.deleteTask(id, userId)
                .flatMap(deletedTask -> {
                    LogEntry log = LogEntry.taskLog("delete_task", userId, deletedTask, null);
                    return projectService.addLog(deletedTask.getProjectId(), log);
                }).then();
    }

    // 6. Додати коментар до задачі
    @PostMapping("/{id}/comments")
    public Mono<Void> addComment(@PathVariable String id, @RequestBody Comment comment) {
        comment.setCreatedAt(new Date());
        return taskService.addComment(id, comment);
    }

    // 7. Всі коментарі задачі
    @GetMapping("/{id}/comments")
    public Flux<Comment> getComments(@PathVariable String id) {
        return taskService.getComments(id);
    }
}
