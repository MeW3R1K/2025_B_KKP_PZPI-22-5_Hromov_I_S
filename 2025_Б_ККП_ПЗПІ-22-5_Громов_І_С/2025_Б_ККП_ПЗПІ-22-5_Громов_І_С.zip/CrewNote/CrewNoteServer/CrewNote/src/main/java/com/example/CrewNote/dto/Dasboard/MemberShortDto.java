package com.example.CrewNote.dto.Dasboard;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberShortDto {
    private String id;
    private String displayName;
    private String photoUrl;
}