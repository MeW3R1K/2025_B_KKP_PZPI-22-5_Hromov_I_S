package com.example.CrewNote.model;

import com.google.cloud.firestore.annotation.DocumentId;
import com.google.cloud.spring.data.firestore.Document;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collectionName = "tasks")
public class Task {
    @DocumentId
    private String id;             // Firestore document id
    private String projectId;      // ID проекту
    private String title;
    private String description;
    private String assignee;       // ID користувача-виконавця
    private Date createdAt;
    private Date updatedAt;
    private Date deadline;
    private List<String> tags;
    private String status;

}
