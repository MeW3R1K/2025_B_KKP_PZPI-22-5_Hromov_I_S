package com.example.CrewNote.dto.Members;

import lombok.Data;

@Data
public class RemoveMemberRequest {
    private String userId;
}
