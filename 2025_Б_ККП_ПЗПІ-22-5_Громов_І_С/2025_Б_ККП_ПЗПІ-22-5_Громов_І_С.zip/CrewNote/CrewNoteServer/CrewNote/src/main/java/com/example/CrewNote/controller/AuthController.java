package com.example.CrewNote.controller;

import com.example.CrewNote.dto.AuthResponse;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseToken;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@Slf4j
public class AuthController {
    @PostMapping("/verify")
    public AuthResponse verify(@RequestBody TokenRequest req) throws Exception {
        // 1. Перевіряємо токен Firebase
        FirebaseToken decoded = FirebaseAuth.getInstance().verifyIdToken(req.getIdToken());
        // 2. Формуємо відповідь
        AuthResponse resp = new AuthResponse();
        resp.setUid(decoded.getUid());
        resp.setEmail(decoded.getEmail());
        resp.setDisplayName(decoded.getName());
        resp.setPhotoUrl(decoded.getPicture());
        log.info("Login success for {}", resp.getEmail());
        return resp;
    }

    // Вхідна структура
    public static class TokenRequest {
        private String idToken;
        public String getIdToken() { return idToken; }
        public void setIdToken(String idToken) { this.idToken = idToken; }
    }
}