package com.example.CrewNote.repository;

import com.example.CrewNote.model.Task;
import com.google.cloud.spring.data.firestore.FirestoreReactiveRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

@Repository
public interface TaskRepository extends FirestoreReactiveRepository<Task> {
    Flux<Task> findByProjectId(String projectId);
    Flux<Task> findByProjectIdAndAssignee(String projectId, String assignee);
}