package com.example.CrewNote.dto.Dasboard;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberStats {
    private String id;
    private String displayName;
    private int tasks; // к-ть задач
}
