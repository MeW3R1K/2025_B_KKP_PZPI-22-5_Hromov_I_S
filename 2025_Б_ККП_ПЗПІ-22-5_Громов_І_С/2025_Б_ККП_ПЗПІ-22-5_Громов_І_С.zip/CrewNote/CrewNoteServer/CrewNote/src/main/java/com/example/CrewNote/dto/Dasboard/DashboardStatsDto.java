package com.example.CrewNote.dto.Dasboard;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DashboardStatsDto {
    private List<StatusCount> statusCounts;
    private int percentDone;
    private List<MemberStats> memberStats;
    private List<TaskShortDto> overdueTasks;
    private List<TaskShortDto> upcomingTasks;
    private List<MemberShortDto> members;
}
