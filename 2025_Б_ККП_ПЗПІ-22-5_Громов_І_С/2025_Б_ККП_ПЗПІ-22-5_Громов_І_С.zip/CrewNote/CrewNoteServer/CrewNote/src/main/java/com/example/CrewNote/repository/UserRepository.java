package com.example.CrewNote.repository;

import com.example.CrewNote.model.User;
import com.google.cloud.spring.data.firestore.FirestoreReactiveRepository;
import reactor.core.publisher.Mono;

public interface UserRepository extends FirestoreReactiveRepository<User> {
    /** Знайти користувача за UID */
    Mono<User> findById(String id);
}

