package com.example.CrewNote.dto.User;

import lombok.Data;

@Data
public class UpdateUserRequest {
    private String displayName; // або username, як тобі зручно
    private String photoUrl;    // або avatar
}
