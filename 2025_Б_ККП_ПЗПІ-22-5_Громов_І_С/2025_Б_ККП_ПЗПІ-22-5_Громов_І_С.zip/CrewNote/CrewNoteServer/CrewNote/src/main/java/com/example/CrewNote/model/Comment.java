package com.example.CrewNote.model;

import com.google.cloud.firestore.annotation.DocumentId;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Comment {
    @DocumentId
    private String id;
    private String authorId;
    private String displayName;
    private Date createdAt;
    private String text;
}
