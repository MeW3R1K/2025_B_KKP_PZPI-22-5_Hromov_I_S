package com.example.CrewNote;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrewNoteApplicationTests {

	@Test
	void contextLoads() {
	}

}
