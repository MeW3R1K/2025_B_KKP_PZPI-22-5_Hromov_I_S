export function logAction({
                              userId,
                              userName,
                              action,
                              targetType,
                              targetId,
                              oldValue = null,
                              newValue = null
                          }) {
    // Покищо просто вивід в консоль або push в масив (для розробки)
    console.log('[LOG]', {
        userId, userName, action, targetType, targetId, oldValue, newValue, timestamp: new Date()
    });
    //TODO
    // Далі тут буде fetch/axios до твого backend API для збереження в БД
    // return fetch('/api/log', { ... })
}
