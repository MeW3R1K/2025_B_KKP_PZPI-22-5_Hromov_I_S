import { Link, useLocation } from "react-router-dom";
import { useAuth } from "./AuthContext";

const menuItems = [
    { label: "Головна",     path: "/home" },
    { label: "Проекти",     path: "/projects" },
    { label: "Профіль",     path: "/profile" },
    { label: "Статистика",  path: "/dashboard" },
];

export default function Sidebar() {
    const location = useLocation();
    const { user, logout } = useAuth();

    return (
        <div className="sidebar">
            <div className="logo">CrewNote</div>
            {menuItems.map((item) => (
                <Link
                    key={item.path}
                    to={item.path}
                    className={`nav-link${location.pathname === item.path ? " active" : ""}`}
                >
                    {item.label}
                </Link>
            ))}
            <div className="logout-wrap">
                {user && (
                    <button onClick={logout} className="nav-link"
                            style={{background: "transparent", border: "none", cursor: "pointer"}}>
                        Вийти
                    </button>
                )}
            </div>
        </div>

    );
}

