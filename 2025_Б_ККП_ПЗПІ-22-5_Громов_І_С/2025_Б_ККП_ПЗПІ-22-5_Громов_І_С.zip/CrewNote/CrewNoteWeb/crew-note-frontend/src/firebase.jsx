// src/firebase.jsx
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";


const firebaseConfig = {
    apiKey: "AIzaSyAiu1oGYz9DTG8-IfobzD9EDGEh8CzbHqM",
    authDomain: "crewnote-e7da8.firebaseapp.com",
    projectId: "crewnote-e7da8",
    storageBucket: "crewnote-e7da8.firebasestorage.app",
    messagingSenderId: "899587350022",
    appId: "1:899587350022:web:d0df17054f4397eb28ed87"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);