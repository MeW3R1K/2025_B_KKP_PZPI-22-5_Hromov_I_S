// Отримати токен із localStorage
export function getAuthToken() {
    return localStorage.getItem('idToken');
}

// Зберегти токен у localStorage
export function setAuthToken(token) {
    localStorage.setItem('idToken', token);
}

// Видалити токен із localStorage
export function removeAuthToken() {
    localStorage.removeItem('idToken');
}
