import React, { useEffect, useState } from "react";
import { apiFetch } from "../apiFetch.js"; // Переконайся, що цей файл є

export default function LogsModal({ logs = [], onClose }) {
    const [userNames, setUserNames] = useState({}); // { userId: displayName }

    useEffect(() => {
        // 1. Зібрати всі унікальні userId з логів
        const ids = Array.from(new Set(logs.map(log => log.userId).filter(Boolean)));
        if (!ids.length) return;
        // 2. Запросити з сервера імена
        (async () => {
            try {
                // POST-запит (масив id), очікує масив об'єктів {id, displayName}
                const res = await apiFetch(`/api/users/batch`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(ids),
                });
                if (res.ok) {
                    const data = await res.json();
                    // Скласти об'єкт { userId: displayName }
                    const nameMap = {};
                    data.forEach(user => {
                        nameMap[user.id] = user.displayName || user.email || user.id;
                    });
                    setUserNames(nameMap);
                }
            } catch (e) {
                // нічого, fallback на id
            }
        })();
    }, [logs]);

    return (
        <div
            onClick={e => { if (e.target === e.currentTarget) onClose(); }}
            style={{
                position: "fixed", top: 0, left: 0, width: "100vw", height: "100vh",
                background: "rgba(0,0,0,0.6)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000
            }}
        >
            <div style={{
                position: "relative",
                background: "#232323",
                color: "#D79879",
                minWidth: 400,
                maxWidth: 540,
                borderRadius: 18,
                boxShadow: "0 4px 32px #0009",
                padding: 28,
                maxHeight: "76vh",
                overflowY: "auto",
                fontSize: 16
            }}>
                <button
                    onClick={onClose}
                    style={{
                        position: "absolute", right: 16, top: 16, background: "transparent", border: "none",
                        fontSize: 28, color: "#fff", cursor: "pointer"
                    }}
                >&times;</button>
                <h2 style={{ marginBottom: 20, color: "#fff" }}>Журнал дій</h2>
                {logs.length === 0 && <div style={{ opacity: .7 }}>Логів поки немає</div>}
                <ul style={{ padding: 0, margin: 0, listStyle: "none" }}>
                    {logs.map(log => (
                        <li key={log.id || log.timestamp + log.action} style={{
                            marginBottom: 14,
                            padding: 14,
                            borderRadius: 13,
                            background: "#222",
                            color: "#D79879",
                            display: "flex",
                            alignItems: "center"
                        }}>
                            <div style={{ flex: 1 }}>
                                <div>
                                    <b>{userNames[log.userId] || log.userId}</b> — {renderAction(log.action)}
                                </div>
                                {log.details && <div style={{ fontSize: 13, opacity: .8, marginTop: 2 }}>{log.details}</div>}
                                <div style={{ fontSize: 12, color: "#b0a09b", marginTop: 2 }}>{log.timestamp}</div>
                            </div>
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    );
}

// Функція для відображення зрозумілих назв дій
function renderAction(action) {
    switch (action) {
        case "add_member":
            return "Додав учасника";
        case "remove_member":
            return "Видалив учасника";
        case "create_task":
            return "Створив завдання";
        case "delete_task":
            return "Видалив завдання";
        case "update_task":
            return "Оновив завдання";
        default:
            return action;
    }
}
