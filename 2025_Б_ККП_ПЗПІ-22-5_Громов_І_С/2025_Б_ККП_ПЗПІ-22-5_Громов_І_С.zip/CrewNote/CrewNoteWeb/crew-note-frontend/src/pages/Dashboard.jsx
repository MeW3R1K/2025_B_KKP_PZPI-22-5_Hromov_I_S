import { useState, useEffect } from "react";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Legend } from "recharts";
import { apiFetch } from "../apiFetch"; // ! НЕ забудь свій apiFetch

const STATUS_LABELS = {
    new: "Нова",
    in_progress: "В процесі",
    done: "Виконано",
};
const STATUS_COLORS = ["#D86746", "#FFA726", "#43a047"];

export default function Dashboard() {
    // === 1. Стан ===
    const [projects, setProjects] = useState([]);
    const [currentProject, setCurrentProject] = useState(null);
    const [tasks, setTasks] = useState([]);
    const [members, setMembers] = useState([]);
    const [loading, setLoading] = useState(true);

    // === 2. Завантаження проектів ===
    useEffect(() => {
        async function fetchProjects() {
            setLoading(true);
            const res = await apiFetch("/api/projects");
            if (res.ok) {
                const data = await res.json();
                setProjects(data);
                if (data.length > 0) setCurrentProject(data[0]);
            }
            setLoading(false);
        }
        fetchProjects();
    }, []);

    // === 3. Завантаження задач та учасників по проекту ===
    useEffect(() => {
        if (!currentProject) {
            setTasks([]);
            setMembers([]);
            return;
        }

        async function fetchTasksAndMembers() {
            setLoading(true);

            // --- Tasks ---
            const resTasks = await apiFetch(`/api/tasks?projectId=${currentProject.id}`);
            let tasksArr = [];
            if (resTasks.ok) tasksArr = await resTasks.json();
            setTasks(tasksArr);

            // --- Members (отримуємо id всіх унікальних виконавців з задач) ---
            const assigneeIds = Array.from(new Set(tasksArr.map(t => t.assignee).filter(Boolean)));
            let membersArr = [];
            if (assigneeIds.length) {
                const resUsers = await apiFetch("/api/users/batch", {
                    method: "POST",
                    body: JSON.stringify(assigneeIds),
                    headers: { "Content-Type": "application/json" }
                });
                if (resUsers.ok) membersArr = await resUsers.json();
            }
            setMembers(membersArr);

            setLoading(false);
        }
        fetchTasksAndMembers();
    }, [currentProject]);

    // === 4. PieChart статусів ===
    const statusCounts = [
        { name: STATUS_LABELS["new"], value: tasks.filter(t => t.status === "new").length },
        { name: STATUS_LABELS["in_progress"], value: tasks.filter(t => t.status === "in_progress").length },
        { name: STATUS_LABELS["done"], value: tasks.filter(t => t.status === "done").length },
    ];

    // === 5. Просрочені задачі ===
    const today = new Date();
    const overdueTasks = tasks.filter(t =>
        t.deadline &&
        new Date(t.deadline) < today &&
        t.status !== "done"
    );

    // === 6. Дедлайни на тиждень вперед ===
    const nextWeek = new Date();
    nextWeek.setDate(today.getDate() + 7);
    const upcomingTasks = tasks.filter(t =>
        t.deadline &&
        new Date(t.deadline) >= today &&
        new Date(t.deadline) <= nextWeek
    ).sort((a, b) => new Date(a.deadline) - new Date(b.deadline));

    // === 7. Інфо по учасниках (статистика задач) ===
    const memberStats = members.map(m => ({
        name: m.displayName || m.email || m.id,
        tasks: tasks.filter(t => t.assignee === m.id).length
    }));

    // === 8. Відсоток виконання ===
    const percentDone = tasks.length
        ? Math.round((tasks.filter(t => t.status === "done").length / tasks.length) * 100)
        : 0;

    // === 9. Селектор проекту ===
    function handleSelectProject(id) {
        const proj = projects.find(p => p.id === id);
        setCurrentProject(proj);
    }

    if (loading) return <div style={{ padding: 32 }}>Завантаження...</div>;

    return (
        <div style={{ padding: 32 }}>
            <h1>Дашборд</h1>

            {/* Селектор проекту */}
            <div style={{ position: "relative", minWidth: 180, marginBottom: 22 }}>
                <select
                    value={currentProject?.id || ""}
                    onChange={e => handleSelectProject(e.target.value)}
                    style={{
                        width: "100%",
                        padding: "14px 40px 14px 20px",
                        borderRadius: 14,
                        border: "2px solid #D86746",
                        background: "#FFF",
                        color: "#181818",
                        fontWeight: 700,
                        fontSize: 16,
                        minWidth: 160,
                        boxShadow: "0 2px 8px #FFD3C220",
                        outline: "none",
                        appearance: "none",
                        WebkitAppearance: "none",
                        MozAppearance: "none",
                        cursor: "pointer",
                        transition: "border 0.18s, box-shadow 0.18s"
                    }}
                >
                    {projects.map(p =>
                        <option key={p.id} value={p.id}>{p.name}</option>
                    )}
                </select>
                <span
                    style={{
                        pointerEvents: "none",
                        position: "absolute",
                        right: 16,
                        top: "50%",
                        transform: "translateY(-50%)",
                        fontSize: 20,
                        color: "#D86746"
                    }}
                >▼</span>
            </div>

            {/* Блок: Графік статусів задач */}
            <div style={{ display: "flex", gap: 30, alignItems: "center", marginBottom: 34 }}>
                <div>
                    <div style={{ fontWeight: 700, marginBottom: 8 }}>Розподіл задач за статусом</div>
                    <ResponsiveContainer width={410} height={210}>
                        <PieChart>
                            <Pie
                                data={statusCounts}
                                cx="50%"
                                cy="50%"
                                labelLine={false}
                                outerRadius={70}
                                dataKey="value"
                                label={({ name, percent }) =>
                                    `${name} (${(percent * 100).toFixed(0)}%)`
                                }
                            >
                                {statusCounts.map((entry, i) => (
                                    <Cell key={`cell-${i}`} fill={STATUS_COLORS[i]} />
                                ))}
                            </Pie>
                            <Tooltip />
                        </PieChart>
                    </ResponsiveContainer>
                </div>
                {/* Прогрес-бар виконання */}
                <div style={{
                    flex: 1, padding: 24, borderRadius: 14, background: "#FFF4EE",
                    border: "1.5px solid #FFD3C2", minWidth: 220, boxShadow: "0 2px 12px #FFD3C210"
                }}>
                    <div style={{ fontWeight: 700, marginBottom: 12 }}>Виконання проекту</div>
                    <div style={{
                        background: "#eee", height: 32, borderRadius: 20, overflow: "hidden",
                        marginBottom: 10, boxShadow: "0 1px 4px #FFD3C210"
                    }}>
                        <div style={{
                            width: `${percentDone}%`, height: "100%",
                            background: "#D86746", color: "#fff", fontWeight: 700,
                            display: "flex", alignItems: "center", justifyContent: "center",
                            transition: "width 0.5s"
                        }}>
                            {percentDone}%
                        </div>
                    </div>
                    <div style={{ fontSize: 15, color: "#D86746" }}>
                        Виконано {tasks.filter(t => t.status === "done").length} із {tasks.length} задач
                    </div>
                </div>
            </div>

            {/* 4. Інфо по учасниках */}
            <div style={{
                marginBottom: 34, padding: 18, background: "#FFF4EE", borderRadius: 16,
                border: "1.5px solid #FFD3C2", boxShadow: "0 2px 12px #FFD3C210"
            }}>
                <div style={{ fontWeight: 700, marginBottom: 10 }}>Задачі по учасниках</div>
                <ResponsiveContainer width="100%" height={180}>
                    <BarChart data={memberStats}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis allowDecimals={false} />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="tasks" fill="#D86746" name="Кількість задач" barSize={32} radius={[10, 10, 0, 0]} />
                    </BarChart>
                </ResponsiveContainer>
            </div>

            {/* 2. Просрочені задачі */}
            <div style={{
                marginBottom: 26, background: "#fff8f5", borderRadius: 16,
                padding: 16, border: "1.5px solid #FFD3C2"
            }}>
                <div style={{ fontWeight: 700, color: "#D86746", marginBottom: 8 }}>
                    Просрочені задачі ({overdueTasks.length})
                </div>
                {overdueTasks.length === 0 && <span style={{ color: "#999" }}>Немає просрочених задач 🎉</span>}
                <ul>
                    {overdueTasks.map(t =>
                        <li key={t.id}><b>{t.title}</b> — до {t.deadline}</li>
                    )}
                </ul>
            </div>

            {/* 3. Дедлайни на тиждень вперед */}
            <div style={{
                marginBottom: 30, background: "#e9fcf9", borderRadius: 16,
                padding: 16, border: "1.5px solid #b3f7e5"
            }}>
                <div style={{ fontWeight: 700, color: "#05957A", marginBottom: 8 }}>
                    Дедлайни на тиждень ({upcomingTasks.length})
                </div>
                {upcomingTasks.length === 0 && <span style={{ color: "#888" }}>Нічого не заплановано</span>}
                <ul>
                    {upcomingTasks.map(t =>
                        <li key={t.id}><b>{t.title}</b> — до {t.deadline}</li>
                    )}
                </ul>
            </div>
        </div>
    );
}
