import { useState } from "react";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { db } from "../firebase";

export default function ProjectCreateForm({ onProjectCreated }) {
    const [name, setName] = useState("");
    const [description, setDescription] = useState("");
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");

    async function handleSubmit(e) {
        e.preventDefault();
        setError("");
        if (!name.trim()) return setError("Назва обовʼязкова");
        setLoading(true);
        try {
            await addDoc(collection(db, "projects"), {
                name,
                description,
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp(),
            });
            setName("");
            setDescription("");
            setLoading(false);
            if (onProjectCreated) onProjectCreated();
        } catch (e) {
            setError("Помилка: " + e.message);
            setLoading(false);
        }
    }

    return (
        <form onSubmit={handleSubmit} style={{ marginTop: 32, background: "#181818", padding: 24, borderRadius: 14 }}>
            <h2 style={{ color: "#D86746", marginBottom: 16 }}>Створити новий проект</h2>
            <input
                type="text"
                placeholder="Назва проекту"
                value={name}
                onChange={e => setName(e.target.value)}
                style={{ width: "100%", padding: 8, marginBottom: 12, borderRadius: 8 }}
                disabled={loading}
                required
            />
            <textarea
                placeholder="Опис проекту"
                value={description}
                onChange={e => setDescription(e.target.value)}
                style={{ width: "100%", padding: 8, marginBottom: 12, borderRadius: 8, resize: "vertical" }}
                disabled={loading}
            />
            <button
                type="submit"
                disabled={loading}
                style={{
                    background: "#D86746", color: "#fff", padding: "8px 18px",
                    borderRadius: 8, fontWeight: 600, border: "none", cursor: "pointer"
                }}>
                {loading ? "Створюється..." : "Створити"}
            </button>
            {error && <div style={{ color: "red", marginTop: 8 }}>{error}</div>}
        </form>
    );
}
