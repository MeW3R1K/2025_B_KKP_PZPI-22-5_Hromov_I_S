import { useAuth } from "../AuthContext"; // твій контекст юзера
import TaskModalView from "./TaskModalView.jsx";
import { apiFetch } from "../apiFetch.js";
import { useState, useEffect, useCallback } from "react";


// Текст для статусів
const STATUS_LABELS = {
    new: "Нова",
    in_progress: "В процесі",
    done: "Виконано",
};

const SORT_OPTIONS = [
    { value: "deadline_asc", label: "Дедлайн ↑" },
    { value: "deadline_desc", label: "Дедлайн ↓" },
    { value: "title_asc", label: "Назва A-Я" },
    { value: "title_desc", label: "Назва Я-A" },
];

export default function TasksPage() {
    const { user } = useAuth(); // { uid, displayName }
    const [tasks, setTasks] = useState([]);
    const [project, setProject] = useState(null);
    const [loading, setLoading] = useState(true);
    const [showModal, setShowModal] = useState(false);
    const [openedTaskId, setOpenedTaskId] = useState(null);
    const [filterStatus, setFilterStatus] = useState("all");
    const [search, setSearch] = useState("");
    const [sort, setSort] = useState("deadline_asc");
    const [rawTasks, setRawTasks] = useState([]);
    const [memberProfiles, setMemberProfiles] = useState([]);

    const mainProjectId = localStorage.getItem("mainProjectId");


    // 1. Винеси fetchData через useCallback щоб не створювалась на кожен рендер
    const fetchData = useCallback(async () => {
        setLoading(true);

        // 1.1 Завантаження проекту
        const resProject = await apiFetch(`/api/projects/${mainProjectId}`);
        let projectObj = null;
        if (resProject.ok) {
            projectObj = await resProject.json();
            setProject(projectObj);
        }

        // 1.2 Завантаження задач
        const res = await apiFetch(`/api/tasks?projectId=${mainProjectId}`);
        if (res.ok) {
            const data = await res.json();
            setRawTasks(data);
        }
        setLoading(false);
    }, [mainProjectId]);

    // 2. Викликати fetchData на старті/зміні projectId
    useEffect(() => {
        if (mainProjectId) fetchData();
    }, [mainProjectId, fetchData]);

    // 3. Завантаження профілів учасників проекту
    useEffect(() => {
        if (!project?.members?.length) return;
        const ids = project.members.map(m => m.id);
        async function fetchNames() {
            const res = await apiFetch("/api/users/batch", {
                method: "POST",
                body: JSON.stringify(ids),
                headers: {"Content-Type": "application/json"}
            });
            if (res.ok) {
                const arr = await res.json();
                setMemberProfiles(arr);
            }
        }
        fetchNames();
    }, [project]);

    // 4. Підтягуємо імена виконавців до задач
    useEffect(() => {
        if (rawTasks.length === 0) {
            setTasks([]);
            return;
        }
        const assigneeIds = Array.from(new Set(rawTasks.map(t => t.assignee).filter(Boolean)));
        async function fetchAssignees() {
            if (assigneeIds.length === 0) {
                setTasks(rawTasks);
                return;
            }
            const res = await apiFetch("/api/users/batch", {
                method: "POST",
                body: JSON.stringify(assigneeIds),
                headers: { "Content-Type": "application/json" }
            });
            if (res.ok) {
                const users = await res.json();
                const idToName = {};
                users.forEach(u => idToName[u.id] = u.displayName);
                setTasks(rawTasks.map(t => ({
                    ...t,
                    assigneeObj: t.assignee
                        ? {
                            id: t.assignee,
                            name: idToName[t.assignee] || t.assignee
                        }
                        : null
                })));
            } else {
                setTasks(rawTasks);
            }
        }
        fetchAssignees();
    }, [rawTasks]);

    // 5. Додавання задачі
    async function handleAddTask(task) {
        const res = await apiFetch("/api/tasks", {
            method: "POST",
            body: JSON.stringify({ ...task, projectId: mainProjectId })
        });
        if (res.ok) {
            await fetchData(); // Оновлюємо одразу після створення!
            setShowModal(false);
        }
    }


    // 3. Перевірка чи юзер менеджер (адмін)
    const isManager = project?.members?.some(
        m => m.id === user?.uid && m.role === "admin"
    );

    // --- Фільтрація, пошук, сортування
    let filtered = tasks.filter(t =>
            (filterStatus === "all" || t.status === filterStatus)
            && (
                t.title?.toLowerCase().includes(search.toLowerCase()) ||
                t.description?.toLowerCase().includes(search.toLowerCase()) ||
                (t.tags && t.tags.join(",").toLowerCase().includes(search.toLowerCase()))
            )
    );
    if (sort === "deadline_asc") filtered.sort((a, b) => (a.deadline || "").localeCompare(b.deadline || ""));
    if (sort === "deadline_desc") filtered.sort((a, b) => (b.deadline || "").localeCompare(a.deadline || ""));
    if (sort === "title_asc") filtered.sort((a, b) => (a.title || "").localeCompare(b.title || ""));
    if (sort === "title_desc") filtered.sort((a, b) => (b.title || "").localeCompare(a.title || ""));

    // Групуємо задачі по статусу
    const grouped = {
        new: filtered.filter(t => t.status === "new"),
        in_progress: filtered.filter(t => t.status === "in_progress"),
        done: filtered.filter(t => t.status === "done"),
    };

    if (!mainProjectId) return <div style={{color:"#D86746"}}>Оберіть основний проект!</div>;
    if (loading) return <div>Завантаження...</div>;
    return (
        <div>
            <h1>Завдання для проекту: <span style={{color:"#D86746"}}>{project?.name || mainProjectId}</span></h1>

            {/* Панель фільтрів, пошуку, сортування */}
            <div style={{
                display: "flex",
                gap: 18,
                margin: "22px 0",
                alignItems: "center",
                justifyContent: "flex-start",
                background: "#FFF4EE",
                padding: "18px 22px",
                borderRadius: 20,
                boxShadow: "0 2px 20px #D8674610",
                border: "1.5px solid #FFD3C2"
            }}>
                {/* Фільтр статусу */}
                <div style={{position: "relative", minWidth: 140}}>
                    <select
                        value={filterStatus}
                        onChange={e => setFilterStatus(e.target.value)}
                        style={{
                            width: "100%",
                            padding: "12px 40px 12px 20px",
                            borderRadius: 14,
                            border: "2px solid #D86746",
                            background: "#FFF",
                            color: "#181818",
                            fontWeight: 700,
                            fontSize: 15,
                            minWidth: 120,
                            boxShadow: "0 2px 8px #FFD3C220",
                            outline: "none",
                            appearance: "none",
                            WebkitAppearance: "none",
                            MozAppearance: "none",
                            cursor: "pointer",
                            transition: "border 0.18s, box-shadow 0.18s"
                        }}
                    >
                        <option value="all">Всі статуси</option>
                        <option value="new">Нова</option>
                        <option value="in_progress">В процесі</option>
                        <option value="done">Виконано</option>
                    </select>
                    {/* Кастомна стрілка ▼ */}
                    <span
                        style={{
                            pointerEvents: "none",
                            position: "absolute",
                            right: 16,
                            top: "50%",
                            transform: "translateY(-50%)",
                            fontSize: 18,
                            color: "#D86746"
                        }}
                    >▼</span>
                </div>

                {/* Пошук */}
                <input
                    type="text"
                    value={search}
                    onChange={e => setSearch(e.target.value)}
                    placeholder="Пошук по задачах..."
                    style={{
                        flex: "1",
                        padding: "12px 22px",
                        borderRadius: 14,
                        border: "2px solid #D86746",
                        background: "#FFF",
                        fontSize: 15,
                        fontWeight: 500,
                        color: "#181818",
                        outline: "none",
                        boxShadow: "0 2px 8px #FFD3C220",
                        transition: "border 0.18s, box-shadow 0.18s",
                    }}
                />

                {/* Сортування */}
                <div style={{position: "relative", minWidth: 170}}>
                    <select
                        value={sort}
                        onChange={e => setSort(e.target.value)}
                        style={{
                            width: "100%",
                            padding: "12px 40px 12px 20px",
                            borderRadius: 14,
                            border: "2px solid #D86746",
                            background: "#FFF",
                            color: "#181818",
                            fontWeight: 700,
                            fontSize: 15,
                            minWidth: 150,
                            boxShadow: "0 2px 8px #FFD3C220",
                            outline: "none",
                            appearance: "none",
                            WebkitAppearance: "none",
                            MozAppearance: "none",
                            cursor: "pointer",
                            transition: "border 0.18s, box-shadow 0.18s"
                        }}
                    >
                        {SORT_OPTIONS.map(opt =>
                            <option key={opt.value} value={opt.value}>{opt.label}</option>
                        )}
                    </select>
                    {/* Кастомна стрілка ▼ */}
                    <span
                        style={{
                            pointerEvents: "none",
                            position: "absolute",
                            right: 16,
                            top: "50%",
                            transform: "translateY(-50%)",
                            fontSize: 18,
                            color: "#D86746"
                        }}
                    >▼</span>
                </div>
            </div>

            {/* --- Кнопка створення тільки для менеджера --- */}
            {isManager && (
                <button
                    onClick={() => setShowModal(true)}
                    style={{
                        background: "#D86746",
                        color: "#fff",
                        fontWeight: "bold",
                        border: "none",
                        borderRadius: 10,
                        padding: "8px 24px",
                        fontSize: 17,
                        margin: "15px 0 30px 0",
                        cursor: "pointer",
                        boxShadow: "0 2px 8px #0001"
                    }}
                >+ Створити завдання</button>
            )}

            {/* Канбан */}
            <div style={{display: "flex", gap: 24}}>
                {Object.keys(grouped).map(status => (
                    <div key={status} style={{flex: 1}}>
                        <h2>{STATUS_LABELS[status]}</h2>
                        {grouped[status].length === 0 && (
                            <div style={{opacity: 0.5}}>Немає задач</div>
                        )}
                        {grouped[status].map(task => (
                            <div
                                key={task.id}
                                onClick={() => setOpenedTaskId(task.id)}
                                style={{
                                    background: "#222",
                                    color: "#D79879",
                                    padding: 16,
                                    borderRadius: 16,
                                    marginBottom: 14,
                                    boxShadow: "0 2px 8px #0002",
                                    cursor: "pointer",
                                    transition: "box-shadow 0.15s",
                                }}
                            >
                                <div style={{fontWeight: "bold", fontSize: 18}}>{task.title}</div>
                                <div style={{fontSize: 14, margin: "8px 0 6px 0"}}>{task.description}</div>
                                <div>
                                    <span style={{
                                        padding: "2px 8px",
                                        borderRadius: 8,
                                        background: "#D86746",
                                        color: "#181818",
                                        marginRight: 8,
                                        fontSize: 12
                                    }}>
                                        {STATUS_LABELS[task.status]}
                                    </span>
                                    {task.tags && task.tags.map(tag => (
                                        <span
                                            key={tag}
                                            style={{
                                                padding: "2px 8px",
                                                borderRadius: 8,
                                                background: "#D79879",
                                                color: "#181818",
                                                marginRight: 5,
                                                fontSize: 12
                                            }}
                                        >{tag}</span>
                                    ))}
                                </div>
                                <div style={{fontSize: 12, marginTop: 6}}>
                                    <b>Дедлайн:</b> {task.deadline}
                                </div>
                                <div style={{fontSize: 12, marginTop: 6}}>
                                    <b>Виконавець:</b> {task.assigneeObj?.name || "—"}
                                </div>
                            </div>
                        ))}
                    </div>
                ))}
            </div>

            {/* Модалки */}
            {showModal && (
                <TaskModal
                    onClose={() => setShowModal(false)}
                    onCreate={handleAddTask}
                    members={memberProfiles}
                />
            )}
            {openedTaskId && (
                <TaskModalView
                    taskId={openedTaskId}
                    onClose={() => setOpenedTaskId(null)}
                    memberProfiles={memberProfiles}
                />
            )}
        </div>
    );
}

// --- Модалка для створення завдання ---
function TaskModal({ onClose, onCreate, members }) {
    const [form, setForm] = useState({
        title: "",
        description: "",
        status: "new",
        tags: "",
        deadline: "",
        assignee: ""
    });

    function handleChange(e) {
        setForm(f => ({ ...f, [e.target.name]: e.target.value }));
    }

    function handleSubmit(e) {
        e.preventDefault();
        if (!form.title.trim() || !form.description.trim() || !form.deadline.trim() || !form.assignee.trim()) return;
        onCreate({
            ...form,
            tags: form.tags.split(",").map(tag => tag.trim()).filter(Boolean),
        });
    }

    return (
        <div style={{
            position: "fixed", top: 0, left: 0, width: "100vw", height: "100vh",
            background: "rgba(0,0,0,0.55)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 999
        }}>
            <div style={{
                background: "#222", padding: 32, borderRadius: 20, minWidth: 350,
                color: "#D79879", boxShadow: "0 6px 32px #0009", position: "relative"
            }}>
                <button
                    onClick={onClose}
                    style={{
                        position: "absolute", right: 16, top: 16, background: "transparent", border: "none",
                        fontSize: 24, color: "#fff", cursor: "pointer"
                    }}
                >&times;</button>
                <h2 style={{ color: "#fff", marginBottom: 22 }}>Нове завдання</h2>
                <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                    <input
                        name="title"
                        placeholder="Назва завдання"
                        value={form.title}
                        onChange={handleChange}
                        style={{ padding: 8, borderRadius: 8, border: "1px solid #888", fontSize: 17 }}
                        required
                    />
                    <textarea
                        name="description"
                        placeholder="Опис"
                        value={form.description}
                        onChange={handleChange}
                        style={{ padding: 8, borderRadius: 8, border: "1px solid #888", fontSize: 15, minHeight: 56 }}
                        required
                    />
                    <select
                        name="status"
                        value={form.status}
                        onChange={handleChange}
                        style={{ padding: 8, borderRadius: 8, border: "1px solid #888", fontSize: 15 }}
                    >
                        <option value="new">Нова</option>
                        <option value="in_progress">В процесі</option>
                        <option value="done">Виконано</option>
                    </select>
                    <input
                        name="tags"
                        placeholder="Теги (через кому, напр. UX/UI, Backend)"
                        value={form.tags}
                        onChange={handleChange}
                        style={{ padding: 8, borderRadius: 8, border: "1px solid #888", fontSize: 15 }}
                    />
                    <input
                        name="deadline"
                        type="date"
                        value={form.deadline}
                        onChange={handleChange}
                        style={{ padding: 8, borderRadius: 8, border: "1px solid #888", fontSize: 15 }}
                        required
                    />
                    <div style={{position: "relative", minWidth: 180, marginBottom: 6}}>
                        <select
                            name="assignee"
                            value={form.assignee}
                            onChange={handleChange}
                            required
                            style={{
                                width: "100%",
                                padding: "12px 40px 12px 20px",
                                borderRadius: 14,
                                border: "2px solid #D86746",
                                background: "#FFF",
                                color: "#181818",
                                fontWeight: 700,
                                fontSize: 15,
                                minWidth: 180,
                                boxShadow: "0 2px 8px #FFD3C220",
                                outline: "none",
                                appearance: "none",
                                WebkitAppearance: "none",
                                MozAppearance: "none",
                                cursor: "pointer",
                                transition: "border 0.18s, box-shadow 0.18s"
                            }}
                        >
                            <option value="">Оберіть виконавця</option>
                            {members.map(m =>
                                <option key={m.id} value={m.id}>
                                    {m.displayName || m.email || m.id}
                                </option>
                            )}
                        </select>
                        <span
                            style={{
                                pointerEvents: "none",
                                position: "absolute",
                                right: 16,
                                top: "50%",
                                transform: "translateY(-50%)",
                                fontSize: 18,
                                color: "#D86746"
                            }}
                        >▼</span>
                    </div>

                    <button
                        type="submit"
                        style={{
                            marginTop: 8,
                            padding: "10px 0",
                            borderRadius: 10,
                            border: "none",
                            background: "#D86746",
                            color: "#fff",
                            fontWeight: "bold",
                            fontSize: 17,
                            cursor: "pointer"
                        }}
                    >
                        Створити завдання
                    </button>
                </form>
            </div>
        </div>
    );
}


