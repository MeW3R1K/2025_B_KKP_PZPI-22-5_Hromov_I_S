import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../AuthContext";
import { auth } from "../firebase";
import { signInWithEmailAndPassword, signInWithPopup, GoogleAuthProvider } from "firebase/auth";
import { setAuthToken } from "../authHelpers.js";
import {apiFetch} from "../apiFetch.js";

export default function Login() {
    const { setUser } = useAuth();
    const navigate = useNavigate();
    const [form, setForm] = useState({ email: "", password: "" });
    const [error, setError] = useState("");

    function handleChange(e) {
        setForm(f => ({ ...f, [e.target.name]: e.target.value }));
    }

    async function refreshProfile() {
        const res = apiFetch("/api/users/me", {

        });
        if (res.ok) {
            const profile = await res.json();
            setUser(profile);
            return profile;
        }
        setUser(null);
        return null;
    }

    // Логін через email+password
    async function handleSubmit(e) {
        e.preventDefault();
        setError("");
        try {
            // 1. Firebase логін
            const cred = await signInWithEmailAndPassword(auth, form.email, form.password);
            const idToken = await cred.user.getIdToken();

            // ЗБЕРІГАЄМО токен у localStorage
            setAuthToken(idToken);

            // 2. Верифікація через твій бекенд
            const res = await fetch("/api/auth/verify", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ idToken }),
            });

            await refreshProfile();

            if (res.ok) {
                const data = await res.json();
                setUser(data); // оновлюємо AuthContext
                navigate("/home");
            } else {
                setError("Невірний логін або пароль.");
            }
        } catch (err) {
            setError("Помилка: " + err.message);
        }
    }

    // Google Login
    async function handleGoogleLogin() {
        setError("");
        try {
            const provider = new GoogleAuthProvider();
            const result = await signInWithPopup(auth, provider);
            const idToken = await result.user.getIdToken();

            // ЗБЕРІГАЄМО токен у localStorage
            setAuthToken(idToken);

            const res = await fetch("/api/auth/verify", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ idToken }),
            });

            if (res.ok) {
                const data = await res.json();
                setUser(data);

                await apiFetch("/api/users", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        id: data.uid, // або data.id
                        email: data.email,
                        displayName: data.displayName,
                        photoUrl: data.photoUrl
                    }),
                });

                navigate("/home");
            } else {
                setError("Google авторизація не вдалася.");
            }
        } catch (err) {
            setError("Google помилка: " + err.message);
        }
    }

    return (
        <div className="auth-container">
            <h2>Вхід</h2>
            <form onSubmit={handleSubmit} className="auth-form">
                <input
                    type="email"
                    name="email"
                    placeholder="Email"
                    value={form.email}
                    onChange={handleChange}
                    required
                />
                <input
                    type="password"
                    name="password"
                    placeholder="Пароль"
                    value={form.password}
                    onChange={handleChange}
                    required
                />
                <button type="submit">Увійти</button>
                <button type="button" onClick={handleGoogleLogin} style={{ marginTop: 8 }}>
                    Увійти через Google
                </button>
                {error && <div style={{ color: "red" }}>{error}</div>}
            </form>
            <div className="auth-footer">
                <span>Не маєте акаунту?</span>
                <Link to="/register">Зареєструватися</Link>
            </div>
        </div>
    );
}
