import { useEffect, useState } from "react";
import { useAuth } from "../AuthContext";
import { apiFetch } from "../apiFetch.js";

// Заготовка для статусів
const STATUS_OPTIONS = [
    { value: "new", label: "Нова" },
    { value: "in_progress", label: "В процесі" },
    { value: "done", label: "Виконано" },
];

function formatTimestamp(ts) {
    if (!ts) return "-";
    if (typeof ts === "string" && !isNaN(Date.parse(ts))) return new Date(ts).toLocaleString();
    if (ts.seconds) return new Date(ts.seconds * 1000).toLocaleString();
    return ts;
}

function getAvatarSrc(avatarUrl) {
    if (!avatarUrl) return "/avatars/default.jpg";
    if (avatarUrl.startsWith("http")) return avatarUrl;
    if (avatarUrl.startsWith("/avatars/")) return avatarUrl;
    return `/avatars/${avatarUrl}.jpg`;
}

export default function TaskModalView({ taskId, onClose, memberProfiles = [] }) {
    const { user } = useAuth();
    const [task, setTask] = useState(null);
    const [comments, setComments] = useState([]);
    const [newComment, setNewComment] = useState("");
    const [loading, setLoading] = useState(true);
    const [editing, setEditing] = useState(false);
    const [localStatus, setLocalStatus] = useState("");
    const [deleting, setDeleting] = useState(false);
    const [commentsWithAuthors, setCommentsWithAuthors] = useState([]);
    const [assigneeObj, setAssigneeObj] = useState(null);

    // --- Завантаження задачі ---
    useEffect(() => {
        if (!taskId) return;
        setLoading(true);
        async function fetchTask() {
            const res = await apiFetch(`/api/tasks/${taskId}`);
            if (res.ok) {
                const t = await res.json();
                setTask(t);
                setLocalStatus(t.status);

                if (t.assignee) {
                    const res2 = await apiFetch("/api/users/batch", {
                        method: "POST",
                        body: JSON.stringify([t.assignee]),
                        headers: { "Content-Type": "application/json" }
                    });
                    if (res2.ok) {
                        const users = await res2.json();
                        if (users.length > 0) setAssigneeObj(users[0]);
                    }
                }
            }
            setLoading(false);
        }
        fetchTask();
    }, [taskId]);

    // --- Завантаження коментарів ---
    useEffect(() => {
        if (!taskId) return;
        async function fetchComments() {
            const res = await apiFetch(`/api/tasks/${taskId}/comments`);
            if (res.ok) {
                const commentsArr = await res.json();
                setComments(commentsArr);
            }
        }
        fetchComments();
    }, [taskId]);

    // --- Підтягуємо імена та аватарки авторів коментарів ---
    useEffect(() => {
        if (comments.length === 0) {
            setCommentsWithAuthors([]);
            return;
        }
        const authorIds = Array.from(new Set(comments.map(c => c.authorId).filter(Boolean)));
        if (authorIds.length === 0) {
            setCommentsWithAuthors(comments);
            return;
        }
        async function fetchAuthors() {
            const res = await apiFetch("/api/users/batch", {
                method: "POST",
                body: JSON.stringify(authorIds),
                headers: { "Content-Type": "application/json" }
            });
            if (res.ok) {
                const users = await res.json(); // [{id, displayName, avatarUrl}]
                const idToUser = {};
                users.forEach(u => idToUser[u.id] = u);
                setCommentsWithAuthors(
                    comments.map(c => ({
                        ...c,
                        authorName: idToUser[c.authorId]?.displayName || idToUser[c.authorId]?.email || c.authorId || "Анонім",
                        authorAvatar: getAvatarSrc(idToUser[c.authorId]?.avatarUrl)
                    }))
                );
            } else {
                setCommentsWithAuthors(comments.map(c => ({
                    ...c,
                    authorName: c.authorId || "Анонім",
                    authorAvatar: "/avatars/default.jpg"
                })));
            }
        }
        fetchAuthors();
    }, [comments]);

    // --- Додати коментар ---
    async function handleAddComment(e) {
        e.preventDefault();
        if (!newComment.trim()) return;
        await apiFetch(`/api/tasks/${taskId}/comments`, {
            method: "POST",
            body: JSON.stringify({
                text: newComment,
                authorId: user?.uid,
                createdAt: new Date().toISOString()
            }),
            headers: { "Content-Type": "application/json" }
        });
        setNewComment("");
        // Оновити коментарі
        const res = await apiFetch(`/api/tasks/${taskId}/comments`);
        if (res.ok) setComments(await res.json());
    }

    // --- Зміна статусу (PATCH на сервер) ---
    async function handleStatusChange(e) {
        const newStatus = e.target.value;
        setLocalStatus(newStatus);
        await apiFetch(`/api/tasks/${taskId}`, {
            method: "PATCH",
            body: JSON.stringify({ status: newStatus }),
            headers: { "Content-Type": "application/json" }
        });
        // Оновити дані таски
        const res = await apiFetch(`/api/tasks/${taskId}`);
        if (res.ok) setTask(await res.json());
    }

    // --- Видалити таску ---
    async function handleDeleteTask() {
        if (!window.confirm("Ви дійсно бажаєте видалити це завдання?")) return;
        setDeleting(true);
        await apiFetch(`/api/tasks/${taskId}`, { method: "DELETE" });
        setDeleting(false);
        onClose();
    }

    if (!taskId) return null;
    if (loading) return (
        <ModalLayout onClose={onClose}><div>Завантаження...</div></ModalLayout>
    );
    if (!task) return (
        <ModalLayout onClose={onClose}><div>Завдання не знайдено</div></ModalLayout>
    );

    return (
        <ModalLayout onClose={onClose}>
            <div>
                <button
                    onClick={onClose}
                    style={{
                        position: "absolute", right: 18, top: 12, background: "transparent", border: "none",
                        fontSize: 30, color: "#fff", cursor: "pointer"
                    }}
                >&times;</button>
                <h2 style={{color:"#fff"}}>{task.title}</h2>
                <div style={{marginBottom: 7, color:"#D79879"}}>
                    <b>Опис:</b> {task.description}
                </div>
                <div style={{marginBottom: 7}}>
                    <b>Теги:</b> {Array.isArray(task.tags) ? task.tags.join(", ") : "-"}
                </div>
                <div style={{marginBottom: 7}}>
                    <b>Виконавець:</b>{" "}
                    {assigneeObj
                        ? `${assigneeObj.displayName || assigneeObj.email || assigneeObj.id}`
                        : "—"}
                </div>
                <div style={{marginBottom: 7}}>
                    <b>Створено:</b> {formatTimestamp(task.createdAt)}
                </div>
                <div style={{marginBottom: 7}}>
                    <b>Оновлено:</b> {formatTimestamp(task.updatedAt)}
                </div>
                <div style={{marginBottom: 7}}>
                    <b>Дедлайн:</b> {formatTimestamp(task.deadline)}
                </div>
                <div style={{marginBottom: 7}}>
                    <b>Статус:</b>
                    <div style={{position: "relative", display: "inline-block"}}>
                        <select
                            value={localStatus}
                            onChange={handleStatusChange}
                            style={{
                                marginLeft: 10,
                                padding: "7px 40px 7px 18px",
                                borderRadius: 12,
                                border: "2px solid #D86746",
                                background: "#2d2320",
                                color: "#fff",
                                fontSize: 15,
                                fontWeight: "bold",
                                outline: "none",
                                appearance: "none",
                                WebkitAppearance: "none",
                                MozAppearance: "none",
                                position: "relative",
                                boxShadow: "0 2px 8px #D8674644",
                                cursor: "pointer",
                                transition: "border 0.2s"
                            }}
                        >
                            {STATUS_OPTIONS.map(opt => (
                                <option
                                    key={opt.value}
                                    value={opt.value}
                                    style={{
                                        background: "#D86746",
                                        color: "#181818",
                                        fontWeight: "bold"
                                    }}
                                >
                                    {opt.label}
                                </option>
                            ))}
                        </select>
                        <span
                            style={{
                                pointerEvents: "none",
                                position: "absolute",
                                right: 18,
                                top: "50%",
                                transform: "translateY(-50%)",
                                fontSize: 17,
                                color: "#D86746"
                            }}
                        >▼</span>
                    </div>
                </div>

                <div style={{display: 'flex', gap: 12, marginTop: 22}}>
                    <button
                        onClick={() => setEditing(true)}
                        style={{
                            background: "#D79879", color: "#181818", border: "none",
                            borderRadius: 10, fontWeight: "bold", fontSize: 15, padding: "8px 20px", cursor: "pointer"
                        }}
                    >Редагувати</button>
                    <button
                        onClick={handleDeleteTask}
                        disabled={deleting}
                        style={{
                            background: "#d34c2e", color: "#fff", border: "none",
                            borderRadius: 10, fontWeight: "bold", fontSize: 15, padding: "8px 20px",
                            cursor: deleting ? "not-allowed" : "pointer"
                        }}
                    >{deleting ? "Видалення..." : "Видалити"}</button>
                </div>
                <hr style={{margin: "20px 0"}}/>
                <h3 style={{color: "#fff"}}>Коментарі:</h3>
                <div style={{marginBottom: 16}}>
                    {commentsWithAuthors.length === 0 && <div>Коментарів ще немає</div>}
                    {commentsWithAuthors.map(c => (
                        <div key={c.id} style={{
                            display: "flex",
                            alignItems: "flex-start",
                            gap: 12,
                            padding: 10,
                            marginBottom: 10,
                            background: '#222',
                            color: '#D79879',
                            borderRadius: 9
                        }}>
                            {/* Аватар */}
                            <img
                                src={c.authorAvatar}
                                alt="avatar"
                                style={{
                                    width: 38, height: 38, borderRadius: "50%",
                                    objectFit: "cover", border: "2px solid #D86746"
                                }}
                                onError={e => e.currentTarget.src = "/avatars/default.jpg"}
                            />
                            <div style={{flex: 1}}>
                                <b style={{color: "#fff", fontSize: 15, fontWeight: "bold"}}>{c.authorName}</b>
                                <div style={{marginTop: 2, fontSize: 15, color: "#D79879"}}>{c.text}</div>
                                <div style={{fontSize: 11, opacity: .7, marginTop: 3}}>
                                    {formatTimestamp(c.createdAt)}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
                <form onSubmit={handleAddComment} style={{display:'flex',gap:8}}>
                    <input
                        value={newComment}
                        onChange={e=>setNewComment(e.target.value)}
                        placeholder="Новий коментар"
                        style={{flex:1, padding:8, borderRadius:8}}
                    />
                    <button style={{padding:'8px 18px', background:'#D86746', border:'none', color:'#fff', borderRadius:8}}>Надіслати</button>
                </form>
            </div>

            {/* Модалка редагування завдання */}
            {editing && (
                <EditTaskModal
                    task={task}
                    onClose={() => setEditing(false)}
                    onSave={async (edited) => {
                        // PATCH to server
                        const res = await apiFetch(`/api/tasks/${task.id}`, {
                            method: "PATCH",
                            body: JSON.stringify(edited),
                            headers: { "Content-Type": "application/json" }
                        });
                        if (res.ok) {
                            const updated = await res.json();
                            setTask(updated);
                            setEditing(false);
                        } else {
                            alert("Помилка при оновленні!");
                        }
                    }}
                    members={memberProfiles || []}
                />
            )}
        </ModalLayout>
    );
}

// --- Layout самої модалки ---
function ModalLayout({children, onClose}) {
    return (
        <div
            onClick={e => { if (e.target === e.currentTarget) onClose(); }}
            style={{
                position: "fixed",
                zIndex: 9999,
                top: 0, left: 0, width: "100vw", height: "100vh",
                background: "rgba(0,0,0,0.7)",
                display: "flex", alignItems: "center", justifyContent: "center"
            }}>
            <div className="modal-scroll"  style={{
                position: "relative",
                minWidth: 400,
                maxWidth: 520,
                background: "#232323",
                color: "#D79879",
                padding: 30,
                borderRadius: 18,
                boxShadow: "0 4px 32px #0009",
                maxHeight: "80vh",
                overflowY: "auto"
            }}>
                {children}
            </div>
        </div>
    );
}

// --- Модалка редагування завдання ---
function EditTaskModal({ task, onClose, onSave, members = [] }) {
    const [form, setForm] = useState({
        title: task.title || "",
        description: task.description || "",
        status: task.status || "new",
        tags: Array.isArray(task.tags) ? task.tags.join(", ") : "",
        deadline: (typeof task.deadline === "string" && task.deadline.length >= 10)
            ? task.deadline.substring(0,10) : "",
        assignee: task.assignee || "",
    });

    function handleChange(e) {
        setForm(f => ({ ...f, [e.target.name]: e.target.value }));
    }

    function handleSubmit(e) {
        e.preventDefault();
        onSave({
            ...form,
            tags: form.tags.split(",").map(t => t.trim()).filter(Boolean),
        });
    }

    return (
        <ModalLayout onClose={onClose}>
            <h2 style={{marginBottom: 15, color:"#fff"}}>Редагування завдання</h2>
            <form onSubmit={handleSubmit} style={{display: "flex", flexDirection: "column", gap: 12}}>
                <input name="title" value={form.title} onChange={handleChange} placeholder="Назва" style={{padding:8, borderRadius:7}} />
                <textarea name="description" value={form.description} onChange={handleChange} placeholder="Опис" style={{padding:8, borderRadius:7}} />
                <div style={{position:"relative"}}>
                    <select
                        name="status"
                        value={form.status}
                        onChange={handleChange}
                        style={{
                            width: "100%",
                            padding: "8px 38px 8px 16px",
                            borderRadius: 8,
                            border: "2px solid #D86746",
                            background: "#FFF",
                            color: "#181818",
                            fontWeight: 700,
                            fontSize: 15,
                            minWidth: 120,
                            boxShadow: "0 2px 8px #FFD3C220",
                            outline: "none",
                            appearance: "none",
                            WebkitAppearance: "none",
                            MozAppearance: "none",
                            cursor: "pointer",
                            transition: "border 0.18s, box-shadow 0.18s"
                        }}
                    >
                        {STATUS_OPTIONS.map(opt => (
                            <option key={opt.value} value={opt.value}>{opt.label}</option>
                        ))}
                    </select>
                    <span
                        style={{
                            pointerEvents: "none",
                            position: "absolute",
                            right: 16,
                            top: "50%",
                            transform: "translateY(-50%)",
                            fontSize: 18,
                            color: "#D86746"
                        }}
                    >▼</span>
                </div>
                <input name="tags" value={form.tags} onChange={handleChange} placeholder="Теги (через кому)" style={{padding:8, borderRadius:7}} />
                <input name="deadline" type="date" value={form.deadline} onChange={handleChange} style={{padding:8, borderRadius:7}} />
                <div style={{position: "relative"}}>
                    <select
                        name="assignee"
                        value={form.assignee}
                        onChange={handleChange}
                        required
                        style={{
                            width: "100%",
                            padding: "8px 38px 8px 16px",
                            borderRadius: 8,
                            border: "2px solid #D86746",
                            background: "#FFF",
                            color: "#181818",
                            fontWeight: 700,
                            fontSize: 15,
                            minWidth: 120,
                            boxShadow: "0 2px 8px #FFD3C220",
                            outline: "none",
                            appearance: "none",
                            WebkitAppearance: "none",
                            MozAppearance: "none",
                            cursor: "pointer",
                            transition: "border 0.18s, box-shadow 0.18s"
                        }}
                    >
                        <option value="">Оберіть виконавця</option>
                        {members.map(m =>
                            <option key={m.id} value={m.id}>
                                {m.displayName || m.email || m.id}
                            </option>
                        )}
                    </select>
                    <span
                        style={{
                            pointerEvents: "none",
                            position: "absolute",
                            right: 16,
                            top: "50%",
                            transform: "translateY(-50%)",
                            fontSize: 18,
                            color: "#D86746"
                        }}
                    >▼</span>
                </div>
                <div style={{display:'flex', gap:12, marginTop:6}}>
                    <button type="button" onClick={onClose} style={{padding:"8px 18px", border:"none", borderRadius:8, background:"#555", color:"#fff"}}>Скасувати</button>
                    <button type="submit" style={{padding:"8px 18px", border:"none", borderRadius:8, background:"#D86746", color:"#fff", fontWeight:"bold"}}>Зберегти</button>
                </div>
            </form>
        </ModalLayout>
    );
}
