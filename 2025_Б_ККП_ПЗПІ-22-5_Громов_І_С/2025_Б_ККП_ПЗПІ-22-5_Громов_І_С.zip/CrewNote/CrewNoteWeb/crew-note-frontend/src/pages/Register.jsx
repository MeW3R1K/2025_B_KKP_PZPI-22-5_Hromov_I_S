import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../AuthContext";
import { auth } from "../firebase";
import { createUserWithEmailAndPassword, updateProfile } from "firebase/auth";
import {apiFetch} from "../apiFetch.js";

export default function Register() {
    const { setUser } = useAuth();
    const navigate = useNavigate();
    const [form, setForm] = useState({ email: "", password: "", name: "", confirmPassword: "", });
    const [error, setError] = useState("");

    function handleChange(e) {
        setForm(f => ({ ...f, [e.target.name]: e.target.value }));
    }

    async function handleSubmit(e) {
        e.preventDefault();
        setError("");

        if (!isPasswordStrong(form.password)) {
            setError(
                "Пароль має містити мінімум 8 символів, латинські літери, 1 велику, 1 малу, 1 цифру та 1 спецсимвол."
            );
            return;
        }

        if (form.password !== form.confirmPassword) {
            setError("Паролі не співпадають.");
            return;
        }

        try {
            // 1. Firebase create user
            const cred = await createUserWithEmailAndPassword(auth, form.email, form.password);
            // Оновити ім'я профілю
            await updateProfile(cred.user, { displayName: form.name });
            const idToken = await cred.user.getIdToken();

            // 2. Верифікація через твій бекенд
            const res = await fetch("http://localhost:8080/api/auth/verify", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ idToken }),
            });

            if (res.ok) {
                const data = await res.json();
                setUser(data);

                // Додаємо юзера у свою БД (якщо ще нема)
                await apiFetch("http://localhost:8080/api/users", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        id: cred.user.uid,
                        email: cred.user.email,
                        displayName: form.name,
                        photoUrl: cred.user.photoURL || ""
                    }),
                });

                navigate("/");
            } else {
                setError("Помилка при реєстрації.");
            }
        } catch (err) {
            setError("Реєстрація: " + err.message);
        }
    }

    function isPasswordStrong(password) {
        // Мінімум 8 символів, 1 велика, 1 мала, 1 цифра, 1 спецсимвол, лише латиниця
        const re = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_])[A-Za-z\d\W_]{8,}$/;
        return re.test(password);
    }


    return (
        <div className="auth-container">
            <h2>Реєстрація</h2>
            <form onSubmit={handleSubmit} className="auth-form">
                <input
                    type="text"
                    name="name"
                    placeholder="Ім'я"
                    value={form.name}
                    onChange={handleChange}
                    required
                />
                <input
                    type="email"
                    name="email"
                    placeholder="Email"
                    value={form.email}
                    onChange={handleChange}
                    required
                />
                <input
                    type="password"
                    name="password"
                    placeholder="Пароль"
                    value={form.password}
                    onChange={handleChange}
                    required
                />
                <input
                    type="password"
                    name="confirmPassword"
                    placeholder="Підтвердіть пароль"
                    value={form.confirmPassword}
                    onChange={handleChange}
                    required
                />
                <small style={{color: '#aaa'}}>
                    Пароль має містити мінімум 8 символів, 1 велика і 1 мала літера, 1 цифра, 1 спецсимвол.
                </small>
                <button type="submit">Зареєструватися</button>
                {error && <div style={{color: "red"}}>{error}</div>}
            </form>
            <div className="auth-footer">
                <span>Вже є акаунт?</span>
                <Link to="/login">Увійти</Link>
            </div>
        </div>
    );
}
