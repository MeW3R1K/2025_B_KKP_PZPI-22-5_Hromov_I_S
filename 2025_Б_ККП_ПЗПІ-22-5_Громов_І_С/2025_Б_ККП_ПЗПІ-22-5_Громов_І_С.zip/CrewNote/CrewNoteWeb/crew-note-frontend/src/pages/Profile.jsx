import { useState, useEffect } from "react";
import { getAuth } from "firebase/auth";
import {getAuthToken} from "../authHelpers.js";
import { apiFetch } from "../apiFetch";

// --- Динамічне отримання списку аватарок (demo-варіант через fetch JSON) ---
async function fetchAvatarOptions() {
    try {
        const res = await fetch("/avatars/avatars.json");
        const list = await res.json();
        return list.map(file => "/avatars/" + file);
    } catch {
        // Fallback
        return ["/avatars/avatar1.jpg"];
    }
}

// --- Отримати Firebase ID токен ---
async function getIdToken() {
    const user = getAuth().currentUser;
    if (user) return await user.getIdToken();
    return null;
}

export default function ProfilePage() {
    const [displayName, setDisplayName] = useState("");
    const [photoUrl, setPhotoUrl] = useState("");
    const [email, setEmail] = useState("");
    const [userId, setUserId] = useState("");
    const [edit, setEdit] = useState(false);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");
    const [avatarOptions, setAvatarOptions] = useState([]);

    // --- Завантаження профілю ---
    useEffect(() => {
        async function fetchUser() {
            setLoading(true);
            setError("");
            let text = "";
            try {
                const token = getAuthToken();

                if (!token) {
                    setError("Користувач не авторизований");
                    setLoading(false);
                    return;
                }

                // Отримати профіль
                const res = await apiFetch("/api/users/me", );
                text = await res.text();

                if (!res.ok) throw new Error("Не вдалося завантажити профіль: " + text);

                let data;
                try {
                    data = JSON.parse(text);
                } catch {
                    throw new Error("Не вдалося розпарсити JSON: " + text);
                }

                setDisplayName(data.displayName || "");
                setPhotoUrl(data.photoUrl || "");
                setEmail(data.email || "");
                setUserId(data.id || "");

            } catch (err) {
                setError("Помилка: " + err.message);
            }
            setLoading(false);
        }
            fetchUser();
    }, []);

    // --- Завантажити список аватарок ---
    useEffect(() => {
        fetchAvatarOptions().then(setAvatarOptions);
    }, []);

    // --- Оновлення профілю ---
    async function handleSave() {
        setError("");
        try {
            const token = getAuthToken();
            if (!token) {
                setError("Користувач не авторизований");
                return;
            }
            const res = await apiFetch("/api/users/me", {
                method: "PATCH",
                body: JSON.stringify({
                    displayName,     // те саме ім'я, що на бекенді!
                    photoUrl         // і тут
                }),
            });
            if (!res.ok) throw new Error("Не вдалося зберегти");
            setEdit(false);
        } catch (err) {
            setError(err.message);
        }
    }

    if (loading) return <div style={{ textAlign: "center", marginTop: 60 }}>Завантаження…</div>;
    if (error) return <div style={{ textAlign: "center", color: "#D86746", marginTop: 60 }}>{error}</div>;

    return (
        <div style={{
            maxWidth: 390, margin: "40px auto",
            background: "#222", borderRadius: 18, color: "#fff",
            padding: 32, boxShadow: "0 2px 18px #0005"
        }}>
            <h2 style={{ textAlign: "center" }}>Профіль користувача</h2>
            <div style={{
                display: "flex", flexDirection: "column",
                alignItems: "center", gap: 16
            }}>
                <img
                    src={photoUrl || avatarOptions[0]}
                    onError={e => {
                        e.target.onerror = null; // щоб не зациклити
                        e.target.src = avatarOptions[0];
                    }}
                    alt="avatar"
                    style={{
                        width: 88, height: 88, borderRadius: "50%",
                        border: "4px solid #D86746", objectFit: "cover"
                    }}
                />
                {edit && (
                    <div style={{
                        display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "center", marginBottom: 8
                    }}>
                        {avatarOptions.map(src => (
                            <img
                                key={src}
                                src={src}
                                alt="option"
                                onClick={() => setPhotoUrl(src)}
                                style={{
                                    width: 46, height: 46, borderRadius: "50%",
                                    border: photoUrl === src ? "3px solid #D86746" : "2px solid #aaa",
                                    cursor: "pointer", objectFit: "cover", background: "#fff"
                                }}
                            />
                        ))}
                    </div>
                )}
            </div>
            <div style={{ marginTop: 30 }}>
                <label>Нікнейм:</label>
                {edit ? (
                    <input
                        value={displayName}
                        onChange={e => setDisplayName(e.target.value)}
                        style={{ width: "100%", padding: 8, borderRadius: 7, margin: "6px 0 15px 0" }}
                    />
                ) : (
                    <div style={{ margin: "5px 0 15px 0", fontSize: 18, color: "#D79879" }}>{displayName}</div>
                )}

                <label>Email:</label>
                <div style={{ margin: "5px 0 15px 0", fontSize: 16, opacity: 0.85 }}>{email}</div>

                <label>ID користувача:</label>
                <div style={{
                    margin: "5px 0 20px 0",
                    fontSize: 15,
                    opacity: 0.75,
                    fontFamily: "monospace",
                    userSelect: "all"
                }}>
                    {userId}
                </div>
            </div>

            {edit ? (
                <div style={{ display: "flex", gap: 12, marginTop: 16 }}>
                    <button
                        onClick={handleSave}
                        style={{ flex: 1, background: "#D86746", color: "#fff", border: "none", borderRadius: 8, padding: "10px 0", fontWeight: "bold" }}
                    >Зберегти</button>
                    <button
                        onClick={() => setEdit(false)}
                        style={{ flex: 1, background: "#555", color: "#fff", border: "none", borderRadius: 8, padding: "10px 0" }}
                    >Скасувати</button>
                </div>
            ) : (
                <button
                    onClick={() => setEdit(true)}
                    style={{ width: "100%", background: "#D86746", color: "#fff", border: "none", borderRadius: 8, padding: "10px 0", fontWeight: "bold", marginTop: 18 }}
                >Редагувати</button>
            )}
        </div>
    );
}
