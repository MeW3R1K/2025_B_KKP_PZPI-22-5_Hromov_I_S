import { useState, useEffect } from "react";
import { apiFetch } from "../apiFetch";


// --- Допоміжна функція для отримання імен масово ---
async function fetchDisplayNamesByIds(ids) {
    if (!ids?.length) return {};
    const res = await apiFetch("/api/users/batch", {
        method: "POST",
        body: JSON.stringify(ids),
        headers: { "Content-Type": "application/json" }
    });
    if (!res.ok) return {};
    const users = await res.json(); // [{id, displayName}]
    const map = {};
    users.forEach(u => map[u.id] = u.displayName || u.email || u.id);
    return map;
}

export default function MembersModal({ project, onClose, onUpdate }) {

    const [members, setMembers] = useState(project.members || []);
    const [displayNames, setDisplayNames] = useState({});
    const [inputId, setInputId] = useState("");
    const [error, setError] = useState("");
    const [confirmRemove, setConfirmRemove] = useState(null);

    // Підтягуємо імена користувачів по id
    useEffect(() => {
        const ids = (members || []).map(m => m.id);
        fetchDisplayNamesByIds(ids).then(setDisplayNames);
    }, [members]);

    // Додаємо учасника (role: "member" по дефолту)
    async function handleAddMember(e) {
        e.preventDefault();
        const trimmedId = inputId.trim();
        if (!trimmedId) return;

        if (members.some(m => m.id === trimmedId)) {
            setError("Такий учасник вже є у проекті!");
            return;
        }

        try {
            const res = await apiFetch(`/api/projects/${project.id}/members`, {
                method: "POST",

                body: JSON.stringify({
                    userId: trimmedId,
                    role: "member"
                })
            });

            if (!res.ok) {
                const errorText = await res.text();
                throw new Error(errorText || "Не вдалося додати учасника.");
            }

            // Якщо бекенд відповів ОК — оновлюємо список
            const updated = [...members, { id: trimmedId, role: "member" }];
            setMembers(updated);
            setInputId("");
            setError("");
            if (onUpdate) onUpdate(updated);

        } catch (err) {
            console.error("Помилка при додаванні:", err);
            setError("Не вдалося додати учасника: " + err.message);
        }
    }


    // Видаляємо учасника
    function handleRemove(id) {
        const updated = members.filter(m => m.id !== id);
        setMembers(updated);
        setConfirmRemove(null);
        if (onUpdate) onUpdate(updated);
    }

    // id адміна для захисту від видалення
    const admin = members.find(m => m.role === "admin");
    const adminId = admin?.id;

    return (
        <div
            onClick={e => { if (e.target === e.currentTarget) onClose(); }}
            style={{
                position: "fixed", zIndex: 9999, top: 0, left: 0,
                width: "100vw", height: "100vh",
                background: "rgba(0,0,0,0.6)", display: "flex", alignItems: "center", justifyContent: "center"
            }}
        >
            <div style={{
                background: "#222", color: "#D79879", borderRadius: 18,
                padding: 28, minWidth: 380, boxShadow: "0 4px 28px #0007", position: "relative"
            }}>
                <button onClick={onClose} style={{
                    position: "absolute", right: 16, top: 10,
                    fontSize: 25, background: "none", border: "none", color: "#fff", cursor: "pointer"
                }}>&times;</button>
                <h2 style={{ color: "#fff", marginBottom: 13 }}>Учасники проєкту</h2>
                <ul style={{ marginBottom: 18, padding: 0, listStyle: "none" }}>
                    {members.map(m => (
                        <li key={m.id} style={{
                            background: "#2d2320", borderRadius: 8, padding: "8px 14px",
                            marginBottom: 8, color: "#fff", display: "flex", alignItems: "center", gap: 10
                        }}>
                            <span>{displayNames[m.id] || m.id}</span>
                            <span>({m.role})</span>
                            {/* Кнопка лише якщо не адмін */}
                            {m.id !== adminId && (
                                <button
                                    style={{ marginLeft: 12, background: "#D86746", color: "#fff", border: "none", borderRadius: 6, cursor: "pointer", padding: "5px 10px" }}
                                    onClick={() => setConfirmRemove(m)}
                                >Видалити</button>
                            )}
                        </li>
                    ))}
                </ul>
                <form onSubmit={handleAddMember} style={{ display: "flex", gap: 10 }}>
                    <input
                        value={inputId}
                        onChange={e => setInputId(e.target.value)}
                        placeholder="ID нового учасника"
                        style={{ flex: 1, padding: 9, borderRadius: 9, border: "1px solid #D86746", fontSize: 15 }}
                    />
                    <button
                        style={{
                            background: "#D86746", color: "#fff", fontWeight: "bold",
                            border: "none", borderRadius: 9, padding: "8px 18px", fontSize: 15, cursor: "pointer"
                        }}
                    >Додати</button>
                </form>
                {error && <div style={{ color: "#D86746", marginTop: 10 }}>{error}</div>}

                {/* Модалка підтвердження видалення */}
                {confirmRemove && (
                    <ConfirmModal
                        name={displayNames[confirmRemove.id] || confirmRemove.id}
                        onCancel={() => setConfirmRemove(null)}
                        onConfirm={() => handleRemove(confirmRemove.id)}
                    />
                )}
            </div>
        </div>
    );
}

function ConfirmModal({ name, onCancel, onConfirm }) {
    return (
        <div style={{
            position: "fixed", zIndex: 10000, top: 0, left: 0,
            width: "100vw", height: "100vh",
            background: "rgba(0,0,0,0.22)", display: "flex", alignItems: "center", justifyContent: "center"
        }}>
            <div style={{
                background: "#fff",
                color: "#181818",
                borderRadius: 14,
                padding: "32px 32px 20px 32px",
                boxShadow: "0 4px 32px #0006",
                minWidth: 280,
                textAlign: "center",
                position: "relative"
            }}>
                <div style={{ fontSize: 18, marginBottom: 17 }}>
                    Ви дійсно бажаєте видалити <b>{name}</b> з учасників?
                </div>
                <div style={{ display: "flex", gap: 15, justifyContent: "center" }}>
                    <button
                        onClick={onCancel}
                        style={{
                            padding: "8px 24px", borderRadius: 8, background: "#bbb", border: "none", color: "#fff", fontWeight: "bold", fontSize: 15, cursor: "pointer"
                        }}>Скасувати</button>
                    <button
                        onClick={onConfirm}
                        style={{
                            padding: "8px 24px", borderRadius: 8, background: "#D86746", border: "none", color: "#fff", fontWeight: "bold", fontSize: 15, cursor: "pointer"
                        }}>Видалити</button>
                </div>
            </div>
        </div>
    );
}
