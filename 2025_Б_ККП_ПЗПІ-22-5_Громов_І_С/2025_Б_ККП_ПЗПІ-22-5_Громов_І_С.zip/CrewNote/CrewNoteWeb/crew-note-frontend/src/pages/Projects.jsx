import { useEffect, useState } from "react";
import { useAuth } from "../AuthContext";
import MembersModal from "./MembersModal";
import LogsModal from "./LogsModal";
import {apiFetch} from "../apiFetch.js";

export default function Projects() {
    const { user } = useAuth(); // поточний юзер (uid, displayName)
    const [projects, setProjects] = useState([]);
    const [selectedId, setSelectedId] = useState(localStorage.getItem("mainProjectId") || null);
    const [showModal, setShowModal] = useState(false);
    const [openedProjectId, setOpenedProjectId] = useState(null);
    const [logsProjectId, setLogsProjectId] = useState(null);
    const [logs, setLogs] = useState([]);
    const [loading, setLoading] = useState(true);

    // Завантаження проектів
    useEffect(() => {
        async function fetchProjects() {
            setLoading(true);
            const res = await apiFetch("/api/projects");
            if (res.ok) {
                let data = await res.json();
                // Для кожного проєкту знайти адміна і додати displayName
                data = await Promise.all(data.map(async (project) => {
                    const admin = project.members?.find(m => m.role === "admin");
                    if (admin) {
                        const adminName = await fetchUserDisplayName(admin.id);
                        return { ...project, managerName: adminName };
                    }
                    return { ...project, managerName: "—" };
                }));

                setProjects(data);
            }
            setLoading(false);
        }
        fetchProjects();
    }, []);

    // Логи по проекту
    useEffect(() => {
        if (!logsProjectId) return;
        async function fetchLogs() {
            const res = await apiFetch(`/api/projects/${logsProjectId}/logs`);
            if (res.ok) {
                const data = await res.json();
                console.log("Fetched logs from API:", data); // <-- додай
                setLogs(data);
            }
        }
        fetchLogs();
    }, [logsProjectId]);

    function isManager(project) {
        return project.members?.some(m => m.id === user.uid && m.role === "admin");
    }

    function handleSelectProject(id) {
        setSelectedId(id);
        localStorage.setItem("mainProjectId", id);
    }

    async function handleAddProject({ name, description }) {
        const token = localStorage.getItem("idToken");
        const res = await apiFetch("/api/projects", {
            method: "POST",
            body: JSON.stringify({ name, description })
        });
        if (res.ok) {
            const data = await res.json();
            setProjects(prev => [...prev, data]);
            setShowModal(false);
        }
    }

    async function fetchUserDisplayName(userId) {
        if (!userId) return "—";
        const res = await apiFetch(`/api/users/${userId}`);
        if (!res.ok) {
            return "—";
        }
        try {
            const user = await res.json();
            return user.displayName || user.email || "—";
        } catch (e) {
            return "—";
        }
    }


    // Локальне оновлення учасників (тільки UI)
    function handleUpdateMembers(projectId, members) {
        setProjects(prev =>
            prev.map(proj =>
                proj.id === projectId ? { ...proj, members } : proj
            )
        );
    }

    if (loading) return <div>Завантаження...</div>;

    return (
        <div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <h1>Проекти</h1>
                <button
                    style={{
                        background: "#D86746",
                        color: "#fff",
                        fontWeight: "bold",
                        border: "none",
                        borderRadius: 10,
                        padding: "8px 20px",
                        fontSize: 16,
                        cursor: "pointer",
                        boxShadow: "0 2px 8px #0001"
                    }}
                    onClick={() => setShowModal(true)}
                >
                    + Створити проект
                </button>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
                {projects.map(proj => (
                    <div
                        key={proj.id}
                        style={{
                            background: "#222",
                            color: "#D79879",
                            padding: 16,
                            borderRadius: 14,
                            border: selectedId === proj.id ? "2px solid #D86746" : "2px solid transparent",
                            boxShadow: selectedId === proj.id ? "0 2px 16px #D86746" : "0 1px 6px #0002"
                        }}
                    >
                        <div style={{ fontWeight: 700, fontSize: 19 }}>{proj.name}</div>
                        <div style={{ fontSize: 15, margin: "7px 0" }}>{proj.description}</div>
                        <div style={{ fontSize: 13, opacity: 0.8 }}>
                            Менеджер: <b>{proj.managerName}</b>
                        </div>


                        <button
                            style={{
                                marginTop: 14,
                                padding: "7px 14px",
                                borderRadius: 10,
                                border: "none",
                                background: selectedId === proj.id ? "#D86746" : "#444",
                                color: selectedId === proj.id ? "#fff" : "#D86746",
                                fontWeight: "bold",
                                cursor: "pointer"
                            }}
                            disabled={selectedId === proj.id}
                            onClick={() => handleSelectProject(proj.id)}
                        >
                            {selectedId === proj.id ? "Основний проєкт" : "Вибрати як основний"}
                        </button>
                        {/* Кнопка керування учасниками лише для менеджера */}
                        {isManager(proj) && (
                            <button
                                style={{
                                    marginTop: 10, marginLeft: 14,
                                    padding: "7px 14px",
                                    borderRadius: 10,
                                    border: "none",
                                    background: "#D79879",
                                    color: "#181818",
                                    fontWeight: "bold",
                                    cursor: "pointer"
                                }}
                                onClick={() => setOpenedProjectId(proj.id)}
                            >
                                Керувати учасниками
                            </button>
                        )}
                        {isManager(proj) && (
                            <>
                                <button
                                    onClick={() => setLogsProjectId(proj.id)}
                                    style={{
                                        marginTop: 10, marginLeft: 14, background: "#77594e", color: "#fff", border: "none",
                                        borderRadius: 10, padding: "8px 22px", cursor: "pointer"
                                    }}
                                >
                                    Переглянути логи
                                </button>
                                {logsProjectId === proj.id && (
                                    <LogsModal
                                        logs={logs}
                                        onClose={() => setLogsProjectId(null)}
                                    />
                                )}
                            </>
                        )}
                    </div>
                ))}
            </div>

            {/* Модальне вікно для створення проекту */}
            {showModal && (
                <ProjectModal
                    onClose={() => setShowModal(false)}
                    onCreate={handleAddProject}
                />
            )}

            {/* Модалка учасників */}
            {openedProjectId && (
                <MembersModal
                    project={projects.find(p => p.id === openedProjectId)}
                    onClose={() => setOpenedProjectId(null)}
                    onUpdate={members => handleUpdateMembers(openedProjectId, members)}
                />
            )}
        </div>
    );
}

// --- Модальне вікно для створення проекту ---
function ProjectModal({ onClose, onCreate }) {
    const [form, setForm] = useState({ name: "", description: "" });

    function handleChange(e) {
        setForm((f) => ({ ...f, [e.target.name]: e.target.value }));
    }

    function handleSubmit(e) {
        e.preventDefault();
        if (!form.name.trim() || !form.description.trim()) return;
        onCreate(form);
    }

    return (
        <div style={{
            position: "fixed", top: 0, left: 0, width: "100vw", height: "100vh",
            background: "rgba(0,0,0,0.55)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 999
        }}>
            <div style={{
                background: "#222", padding: 32, borderRadius: 20, minWidth: 350,
                color: "#D79879", boxShadow: "0 6px 32px #0009", position: "relative"
            }}>
                <button
                    onClick={onClose}
                    style={{
                        position: "absolute", right: 16, top: 16, background: "transparent", border: "none",
                        fontSize: 24, color: "#fff", cursor: "pointer"
                    }}
                >&times;</button>
                <h2 style={{ color: "#fff", marginBottom: 22 }}>Новий проект</h2>
                <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                    <input
                        name="name"
                        placeholder="Назва проекту"
                        value={form.name}
                        onChange={handleChange}
                        style={{ padding: 8, borderRadius: 8, border: "1px solid #888", fontSize: 17 }}
                        required
                    />
                    <textarea
                        name="description"
                        placeholder="Опис"
                        value={form.description}
                        onChange={handleChange}
                        style={{ padding: 8, borderRadius: 8, border: "1px solid #888", fontSize: 15, minHeight: 56 }}
                        required
                    />
                    <button
                        type="submit"
                        style={{
                            marginTop: 8,
                            padding: "10px 0",
                            borderRadius: 10,
                            border: "none",
                            background: "#D86746",
                            color: "#fff",
                            fontWeight: "bold",
                            fontSize: 17,
                            cursor: "pointer"
                        }}
                    >
                        Створити проект
                    </button>
                </form>
            </div>
        </div>
    );
}
