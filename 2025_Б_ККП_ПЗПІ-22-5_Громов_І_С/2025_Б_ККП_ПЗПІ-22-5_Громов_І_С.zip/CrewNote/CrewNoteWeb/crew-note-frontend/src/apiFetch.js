import { auth } from "./firebase";

export async function apiFetch(url, options = {}) {
    const user = auth.currentUser;
    if (!user) throw new Error("Не авторизовано");
    const token = await user.getIdToken(true); // оновлює токен!
    const headers = {
        ...options.headers,
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json"
    };
    return fetch(url, { ...options, headers });
}