import {BrowserRouter as Router, Routes, Route, Navigate, useLocation} from "react-router-dom";
import Home from "./pages/Home";
import Projects from "./pages/Projects";
import Profile from "./pages/Profile";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Sidebar from "./Sidebar";
import PrivateRoute from "./PrivateRoute";
import Dashboard from "./pages/Dashboard.jsx";

// Створюємо окремий Layout, бо useLocation можна тільки в дочірніх компонентах Router!
function Layout() {
    const location = useLocation();
    const hideSidebar = location.pathname === "/login" || location.pathname === "/register";

    if (hideSidebar) {
        // Рендеримо ТІЛЬКИ логін/реєстрацію без жодних div зверху!
        return (
            <main style={{
                width: "100vw",
                minHeight: "100vh",
                background: "#f9ddcc", // бежевий фон
                display: "flex",
                alignItems: "center",
                justifyContent: "center"
            }}>
                <Routes>
                    <Route path="/login" element={<Login/>}/>
                    <Route path="/register" element={<Register/>}/>
                </Routes>
            </main>
        );
    }

    // Якщо не логін/реєстрація — рендеримо layout з Sidebar
    return (
        <div style={{display: "flex", minHeight: "100vh", background: "var(--dark)"}}>
            <Sidebar/>
            <main className="main-content" style={{flex: 1}}>
                <Routes>
                    <Route path="/" element={<Navigate to="/home"/>}/>
                    <Route path="/home" element={<PrivateRoute><Home/></PrivateRoute>}/>
                    <Route path="/projects" element={<PrivateRoute><Projects/></PrivateRoute>}/>
                    <Route path="/profile" element={<PrivateRoute><Profile/></PrivateRoute>}/>
                    <Route path="/dashboard" element={<PrivateRoute><Dashboard/></PrivateRoute>}/>
                </Routes>
            </main>
        </div>
    );
}

export default function App() {

    return (
        <Router>
            <Layout/>
        </Router>
    );
}
