import { createContext, useContext, useState, useEffect } from "react";
import { removeAuthToken } from "./authHelpers.js";

const AuthContext = createContext();

export function useAuth() {
    return useContext(AuthContext);
}

export function AuthProvider({ children }) {
    const [user, setUser] = useState(() => {
        const data = localStorage.getItem("user");
        return data ? JSON.parse(data) : null;
    });

    useEffect(() => {
        if (user) localStorage.setItem("user", JSON.stringify(user));
        else localStorage.removeItem("user");
    }, [user]);

    // --- Головна функція підвантаження профілю
    async function refreshProfile(token) {
        try {
            const res = await fetch("http://localhost:8080/api/users/me", {
                headers: {
                    "Authorization": "Bearer " + (token || localStorage.getItem("idToken")),
                },
            });
            if (res.ok) {
                const profile = await res.json();
                setUser(profile);
                return profile;
            }
        } catch {}
        setUser(null);
        return null;
    }

    // --- Для кастомної реєстрації через email
    async function register(email, password, name) {
        const res = await fetch("http://localhost:8080/api/auth/register", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, password, name }),
        });
        if (res.ok) {
            const data = await res.json();
            setUser(data.user || data);
            return true;
        }
        return false;
    }

    // --- Для кастомного логіну
    async function login(email, password) {
        const res = await fetch("http://localhost:8080/api/auth/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, password }),
        });
        if (res.ok) {
            const data = await res.json();
            setUser(data.user || data);
            return true;
        }
        return false;
    }

    // --- Google/Firebase логін
    async function loginWithGoogle(idToken) {
        // Зберігаємо idToken в localStorage (для автоматичного логіну)
        localStorage.setItem("idToken", idToken);
        await refreshProfile(idToken); // Підтягуємо профіль після verify
    }

    function logout() {
        setUser(null);
        removeAuthToken();
        localStorage.removeItem("idToken");
    }

    // --- При першому запуску перевіряємо idToken
    useEffect(() => {
        const token = localStorage.getItem("idToken");
        if (!user && token) {
            refreshProfile(token);
        }
    }, []);

    return (
        <AuthContext.Provider value={{
            user, setUser, login, register, refreshProfile, logout, loginWithGoogle
        }}>
            {children}
        </AuthContext.Provider>
    );
}
