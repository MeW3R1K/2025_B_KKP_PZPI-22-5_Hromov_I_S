
import { useEffect, useState } from "react";

// Демо-дані (поки так, потім з сервера)
const DEMO_TASKS = [
    {
        id: "JkVGFFFa0GYT8OfgVe3p",
        title: "Верстати головну сторінку",
        description: "Зробити макет, адаптивність, базову валідацію.",
        status: "new",
        tags: ["Frontend", "UX/UI"],
        deadline: "2025-06-28",
        assignee: { name: "Іван", avatarUrl: "" }
    },
    {
        id: 2,
        title: "Підключити Firebase Auth",
        description: "Реалізувати Google Login та Email/Password.",
        status: "in_progress",
        tags: ["Backend"],
        deadline: "2025-06-25",
        assignee: { name: "Оля", avatarUrl: "" }
    },
    {
        id: 3,
        title: "Створити тестову задачу",
        description: "Для перевірки drag&drop.",
        status: "done",
        tags: ["Frontend"],
        deadline: "2025-06-22",
        assignee: { name: "Петро", avatarUrl: "" }
    },
    {
        id: 4,
        title: "Верстати головну сторінку",
        description: "Зробити макет, адаптивність, базову валідацію.",
        status: "new",
        tags: ["Frontend", "UX/UI"],
        deadline: "2025-06-28",
        assignee: { name: "Іван", avatarUrl: "" }
    },
    {
        id: 5,
        title: "Підключити Firebase Auth",
        description: "Реалізувати Google Login та Email/Password.",
        status: "in_progress",
        tags: ["Backend"],
        deadline: "2025-06-25",
        assignee: { name: "Оля", avatarUrl: "" }
    },
    {
        id: 6,
        title: "Створити тестову задачу",
        description: "Для перевірки drag&drop.",
        status: "done",
        tags: ["Frontend"],
        deadline: "2025-06-22",
        assignee: { name: "Петро", avatarUrl: "" }
    },
    {
        id: 7,
        title: "Верстати головну сторінку",
        description: "Зробити макет, адаптивність, базову валідацію.",
        status: "new",
        tags: ["Frontend", "UX/UI"],
        deadline: "2025-06-28",
        assignee: { name: "Іван", avatarUrl: "" }
    },
    {
        id: 8,
        title: "Підключити Firebase Auth",
        description: "Реалізувати Google Login та Email/Password.",
        status: "in_progress",
        tags: ["Backend"],
        deadline: "2025-06-25",
        assignee: { name: "Оля", avatarUrl: "" }
    },
    {
        id: 9,
        title: "Створити тестову задачу",
        description: "Для перевірки drag&drop.",
        status: "done",
        tags: ["Frontend"],
        deadline: "2025-06-22",
        assignee: { name: "Петро", avatarUrl: "" }
    },
    {
        id: 10,
        title: "Верстати головну сторінку",
        description: "Зробити макет, адаптивність, базову валідацію.",
        status: "new",
        tags: ["Frontend", "UX/UI"],
        deadline: "2025-06-28",
        assignee: { name: "Іван", avatarUrl: "" }
    },
    {
        id: 11,
        title: "Підключити Firebase Auth",
        description: "Реалізувати Google Login та Email/Password.",
        status: "in_progress",
        tags: ["Backend"],
        deadline: "2025-06-25",
        assignee: { name: "Оля", avatarUrl: "" }
    },
    {
        id: 12,
        title: "Створити тестову задачу",
        description: "Для перевірки drag&drop.",
        status: "in_progress",
        tags: ["Frontend"],
        deadline: "2025-06-22",
        assignee: { name: "Петро", avatarUrl: "" }
    },
]; // підключи свої дані
const DEMO_MEMBERS = [
    { id: "U7hzNPwfwRNjMTFup60jjQ6RRDx2", name: "Іван" },
    { id: "abcdef123456", name: "Оля" }
];
const DEMO_LOGS = [
    {
        id: 1,
        userId: "U7hz...",
        userName: "Іван",
        action: "add_member",
        timestamp: "2025-06-24 21:17",
        target: "Олег",
        details: "Додав Олега до проекту"
    },
    {
        id: 2,
        userId: "U7hz...",
        userName: "Іван",
        action: "remove_member",
        timestamp: "2025-06-24 21:19",
        target: "Петро",
        details: "Видалив Петра з проекту"
    }
];

export default function useDashboardData() {
    const [tasks, setTasks] = useState([]);
    const [members, setMembers] = useState([]);
    const [logs, setLogs] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Тут буде запит на сервер або Firebase
        setTimeout(() => {
            setTasks(DEMO_TASKS);
            setMembers(DEMO_MEMBERS);
            setLogs(DEMO_LOGS);
            setLoading(false);
        }, 500); // імітація затримки
    }, []);

    // TODO: додати реальний fetch з бекенду в майбутньому
    return { tasks, members, logs, loading };
}
