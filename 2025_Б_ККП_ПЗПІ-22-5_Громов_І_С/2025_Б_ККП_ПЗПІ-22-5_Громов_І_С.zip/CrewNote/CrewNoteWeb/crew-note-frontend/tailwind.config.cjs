// tailwind.config.js
/** @type {import('tailwindcss').Config} */
module.exports = {
    content: [
        "./index.html",
        "./src/**/*.{js,jsx,ts,tsx}",
    ],
    theme: {
        extend: {
            colors: {
                dark: { 500: "#181818" },
                orange: { 500: "#D86746" },
                neutral: { 500: "#D79879" },
            },
        },
    },
    plugins: [],
}
